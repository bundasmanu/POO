#pragma once
#ifndef EXPLORADORA_H
#define EXPLORADORA_H
#include<iostream>
#include<string>
#include <cstdlib>
#include "Formigas.h"
/*#include "Regras.h"*/

using namespace std;

class Exploradora : public Formigas {
	char letra;//contem o caracter relativo a cada tipo de formiga
	int *meu_n_serie;
public:
	Exploradora(int,int);
	virtual ~Exploradora() { delete meu_n_serie; }
	virtual string Obtem_info();
	virtual char Obtem_car();
	virtual int get_nserie() const;
	virtual int get_rm() const;
	virtual int get_rv() const;
	virtual double get_energia_retira_migalha() const;
	virtual void desenha_formiga(int);
	virtual void Comportamento();
	virtual void variacao_energia(int, int);
	Formigas * clone() { return new Exploradora(*this); }
	Exploradora(const Exploradora &);
	Exploradora & operator=(const Exploradora &);
};

#endif // !EXPLORADORA_H

