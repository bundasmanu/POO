#pragma once
#ifndef FORMIGAS_H
#define FORMIGAS_H
#include<iostream>
#include<string>
#include<sstream>
#include<random>//biblioteca de geracao de valores aleatorios
#include "Consola.h"

using namespace std;

class Ninho;
class Tela;
class Comunidade;
class Regras;

class Formigas {
	//ponteiro para o seu ninho
	//ponteiro para as regras
	static int n_serie;
	int linha;
	int coluna;
	int energia_inicial;//energia inicial da formiga
	int energia;//energia que vai tendo ao longo das iteracoes
	const int r_visao;
	const int r_mov;
	const double energia_retira_migalha;
	int entrei_ninho;
	Ninho *ni;
	Comunidade *c;
	vector<Regras*> regrass;
public:
	Formigas(int,int,int,int,int,double);
	virtual ~Formigas();
	int get_energia_inicial() const;
	int get_linha() const;
	int get_coluna() const;
	void set_linha(int);
	void set_coluna(int);
	virtual string Obtem_info();
	virtual char Obtem_car();
	int get_energia() const;
	void set_energia(int);
	void move_energia(int);
	void move_patas(int, int);
	void set_ninho(Ninho *);//sera que necessita de ser virtual??
	int get_ninho() const;
	int get_entrei_ninho() const;
	virtual int get_nserie() const { return n_serie; }//alterei
	void set_comunidade(Comunidade *);
	bool verifica_energia();
	virtual int get_rm() const;
	virtual int get_rv() const;
	virtual double get_energia_retira_migalha() const;
	bool estou_no_ninho();
	void atuar_quando_estou_no_ninho();
	virtual void Comportamento();
	virtual void variacao_energia(int l, int c);
	virtual void desenha_formiga(int);
	bool posso_andar(int,int);//pergunto ao Mundo ao qual pertenco, se posso ir para uma dada posicao
	bool encontrei_inimiga(int, int);//verifica se numa determinada posicao esta uma formiga que nao pertence a sua comunidade, perguntando isto � Classe Tela
	bool encontrei_amiga(int, int);//verifca se numa determinada posicao esta uma formiga que pertence � sua comunidade, perguntando isto � Classe Tela
	bool encontrei_migalha(int, int);//pergunta ao Mundo se numa determinada posicao se encontra uma migalha
	Comunidade * retorna_minha_comunidade();//acho que nao vai ser preciso
	int pergunta_ninho_linha() const;
	int pergunta_ninho_coluna() const;
	virtual void acrescenta_regras(Regras *);
	virtual Formigas * clone() = 0;
	Formigas(const Formigas &);
	Formigas & operator=(const Formigas &);
};

#endif // !FORMIGAS_H

