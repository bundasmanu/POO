#include "Migalhas.h"
#include "Tela.h"

Migalhas::Migalhas(int e, int l, int c) : energia_inicial(e) {
	this->energia = new int(e);
	this->linha = l;
	this->coluna = c;
}

Migalhas::~Migalhas() {
	delete energia;
}

int Migalhas::get_energia() const {
	return *energia;
}

int Migalhas::get_linha() const {
	return this->linha;
}

int Migalhas::get_coluna() const {
	return this->coluna;
}

void Migalhas::set_energia(int n) {
	*energia = n;
}

void Migalhas::move_energia(int n) {
	this->set_energia(n);
}

string Migalhas::Obtem_info() const {
	ostringstream frase;
	frase << "Migalha: \n" << "\tEnergia: " << this->get_energia() << " Linha: " << this->get_linha() << " Coluna: " << this->get_coluna() << "\n";
	return frase.str();
}

void Migalhas::set_tela(Tela *t) {
	this->te = t;
}

void Migalhas::verifica_energia() {
	if (*energia< energia_inicial*0.10) {
		this->te->remove_migalha(this->get_linha(), this->get_coluna());
	}
}

void Migalhas::desenha_migalha() {
	Consola::setScreenSize(15, 15);
	Consola::setTextColor(15);
	Consola::gotoxy(this->get_coluna(), this->get_linha());//tem de ser x->corresponde � coluna e y-> � linha, logo (coluna,linha)
	if (*this->energia > (this->energia_inicial*0.5)) {
		cout << (char)toupper('m');
	}
	else {
		cout << (char)tolower('m');
	}
}

int* Migalhas::posicao_vazia_aleatoria(int x[]) {
	bool confirmacao = false;

	//aqui esta presente o mecanismo de geracao de numeros aleatorios, recorri � biblioteca time para gerar de uma forma mais aleatoria os numeros
	std::default_random_engine generator((unsigned int)time(0));
	std::uniform_int_distribution<int> distribution(11, te->get_linhas() + 10);//area onde os elementos podem andar

	do {
		for (int i = 0; i < 2; ++i) {
			x[i] = distribution(generator);
		}
		//garanto que esta msm vazia
		if (this->te->posicao_vazia(x[0], x[1]) == true) {//so saio do ciclo se a posicao que foi gerada se encontrar vazia
			confirmacao = true;
		}
		//if aquela posicao tiver vazia, coloco bool=true senao bool=false
		//so para quando encontrar uma posicao vazia
	} while (confirmacao != true);
	//pronto depois j� posso aplicar os numeros gerados no novo elemento criado
	return x;
}

Migalhas::Migalhas(const Migalhas &m) : energia_inicial(m.energia_inicial){
	//this->te = new Tela(m.te->get_linhas(),);
	this->coluna = m.coluna;
	this->linha = m.linha;
	this->energia = new int(*m.energia);
}

Migalhas & Migalhas::operator=(const Migalhas &m) {
	delete energia;
	delete this->te;

	/*redefinicao dos novos atributos*/
	//this->te = new Tela(m.te->get_linhas());
	this->coluna = m.coluna;
	this->linha = m.linha;
	this->energia = new int(*m.energia);
	return (*this);
}