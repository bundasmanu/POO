#include "Ninho.h"
#include "Comunidade.h"

Ninho::Ninho(int l, int c,int e) {//a energia inicial � igual � energia
	this->linha = l;
	this->coluna = c;
	this->n_serie = this->n_serie + 1;
	this->energia_inicial = e;
	this->energia = e;
	this->n_serie_oficial = new int(this->n_serie);
}

Ninho::~Ninho() {
	delete n_serie_oficial;
}

int Ninho::get_linha() const{
	return this->linha;
}

int Ninho::get_coluna() const {
	return this->coluna;
}

int Ninho::get_energia() const {
	return this->energia;
}

void Ninho::set_energia(int n) {
	this->energia = n;
}

int Ninho::get_nserie() const{
	return *n_serie_oficial;
}

void Ninho::set_comunidade(Comunidade *k) {
	this->cc = k;
}

int Ninho::verifica_energia() {
	if (this->get_energia() <= 1) {
		this->cc->remove_ninho();
		return 0;//se morreu
	}
	return 1;//se continua vivo
}

string Ninho::lista_ninho() {
	ostringstream frase;
	frase << "Ninho: " << this->get_nserie() << " Posicao: (" << this->get_linha() << "," << this->get_coluna() << ") " << "Energia: " << this->energia << "\n";
	return frase.str();
}

void Ninho::desenha_ninho(int cor) {
	Consola::gotoxy(this->get_coluna(), this->get_linha());//tem de ser x->corresponde � coluna e y-> � linha, logo (coluna,linha)
	Consola::setTextColor(cor);
	Consola::setTextSize(15, 15);
	cout << (char)toupper('n');
}

void Ninho::move_energia(int n) {
	this->set_energia(n);
}

void Ninho::cria_nova_formiga() {
	int energia_validar = this->energia_inicial+(this->energia_inicial*cc->get_defpc() / 100);
	if (this->energia > energia_validar) {
		std::default_random_engine generator((unsigned int)time(0));
		std::uniform_int_distribution<int> distribution(0, 5);//retorna uma posicao aleatoria
		int posicao_aleatoria = distribution(generator);//gero numero aleatorio de uma das posicoes do vetor de posicoes permitidas opostas
		if (posicao_aleatoria == 1) {
			cc->acrescenta_formigas('C', cc->numero_formigas() + 1, this->linha, this->coluna);
		}
		if (posicao_aleatoria == 2) {
			cc->acrescenta_formigas('V', cc->numero_formigas() + 1, this->linha, this->coluna);
		}
		if (posicao_aleatoria == 3) {
			cc->acrescenta_formigas('A', cc->numero_formigas() + 1, this->linha, this->coluna);
		}
		if (posicao_aleatoria == 4) {
			cc->acrescenta_formigas('E', cc->numero_formigas() + 1, this->linha, this->coluna);
		}
		if (posicao_aleatoria == 5) {
			cc->acrescenta_formigas('S', cc->numero_formigas() + 1, this->linha, this->coluna);
		}
	}
}

Ninho::Ninho(const Ninho &n) {
	//this->cc = new Comunidade(n.cc->get_linha_ninho(),n.cc->get_coluna_ninho());
	this->coluna = n.coluna;
	this->energia_inicial = n.energia_inicial;
	this->energia = n.energia;
	this->linha = n.linha;
	this->n_serie_oficial = new int(*n.n_serie_oficial);
}

Ninho & Ninho::operator=(const Ninho &n) {
	delete cc;
	delete this->n_serie_oficial;

	/*redefinicao dos novos atributos*/
	this->coluna = n.coluna;
	this->linha = n.linha;
	this->energia = n.energia;
	this->energia_inicial = n.energia_inicial;
	//this->cc = new Comunidade(n.cc->get_linha_ninho(), n.cc->get_coluna_ninho());
	this->n_serie_oficial = new int(*n.n_serie_oficial);
	return (*this);
}

int Ninho::n_serie = 0;