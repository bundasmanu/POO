#include "RegraPersegue.h"
#include "Comunidade.h"
#include "Tela.h"

RegraPersegue::RegraPersegue() {

}

RegraPersegue::~RegraPersegue() {

}

bool RegraPersegue::condicao_regra(Formigas *f) {
	return Regras::verifica_formiga_inimiga_raio_visao(f);
}

void RegraPersegue::executa_regra(Formigas *f) {
	/*Para a formiga a analisar verifico qual a formiga inimiga que se encontra mais proxima de si,
	mediante a posicao onde a formiga inimiga se encontra, desloco-me para uma posi��o
	contr�ria a essa formiga inimiga*/

	/*OBTENCAO DA POSICAO DA FORMIGA E DO SEU RAIO DE VISAO*/
	int raio_visao_formiga = f->get_rv();
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	//cout << x_inicio << endl;

	/*POSICOES QUE PODEM SER VISUALIZADAS PELA FORMIGA*/
	int x_max_vis = x_inicio + f->get_rv();
	int x_min_vis = x_inicio - f->get_rv();
	int y_min_vis = y_inicio - f->get_rv();
	int y_max_vis = y_inicio + f->get_rv();

	/*VETOR DE X E Y QUE GUARDA AS POSICOES DAS FORMIGAS INIMIGAS*/
	vector<int> x_inimigas;
	vector<int> y_inimigas;

	/*PERCORRER AS POSICOES PARA AS QUAIS A FORMIGA PODE ACEDER, GUARDANDO NO VETOR, AS POSICOES ONDE SE ENCONTRAM AS FORMIGAS INIMIGAS*/
	for (int i = x_min_vis; i < x_max_vis; ++i) {
		for (int j = y_min_vis; j < y_max_vis; ++j) {
			if (f->encontrei_inimiga(i, j) == true) {
				x_inimigas.push_back(i);
				y_inimigas.push_back(j);
			}
		}
	}

	/*VERIFICAR QUAL A INIMIGA QUE POSSUI MAIS ENERGIA*/
	int posicao_no_vetor_formiga_mais_energia = Regras::qual_formiga_tem_mais_energia(f, x_inimigas, y_inimigas);

	/*POSICAO ONDE SE ENCONTRA A FORMIGA INIMIGA COM MAIS ENERGIA*/
	int x_inimiga_mais_energia = x_inimigas[posicao_no_vetor_formiga_mais_energia];
	int y_inimiga_mais_energia = y_inimigas[posicao_no_vetor_formiga_mais_energia];

	/*CHAMADA DA FUNCAO QUE RETORNA O VETOR COM A POSICAO DA APROXIMACAO A FORMIGA INIMIGA*/
	vector<int>nova_posicao;
	nova_posicao = Regras::aproximacao_formiga_inimiga_ou_migalha(f, x_inimiga_mais_energia, y_inimiga_mais_energia);
	
	/*A FORMIGA MOVE SE PARA A SUA NOVA POSICAO*/
	f->variacao_energia(nova_posicao[0], nova_posicao[1]);
	f->move_patas(nova_posicao[0], nova_posicao[1]);
}