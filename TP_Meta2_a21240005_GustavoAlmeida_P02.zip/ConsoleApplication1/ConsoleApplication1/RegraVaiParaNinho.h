#pragma once
#ifndef REGRAVAIPARANINHO_H
#define REGRAVAIPARANINHO_H
#include<iostream>
#include<string>
#include "Regras.h"

class RegraVaiParaNinho : public Regras{

public:
	RegraVaiParaNinho();
	~RegraVaiParaNinho();
	bool ninho_no_raio_de_visao_formiga(Formigas *);
	bool ninho_no_raio_de_movimento_formiga(Formigas *);
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraVaiParaNinho(*this); }
};


#endif // !REGRAVAIPARANINHO_H
