#include "RegraSacrificar.h"
#include "Comunidade.h"
#include "Tela.h"

Regrassacrificar::Regrassacrificar() {

}

Regrassacrificar::~Regrassacrificar() {

}

bool Regrassacrificar::formiga_inimiga_no_raio_movimento(Formigas *f) {

	/*POSICOES INICIAIS DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*VERTICES DO RAIO DE MOVIMENTO DA FORMIGA*/
	int x_mov_min = f->get_linha() - f->get_rm();
	int x_mov_max = f->get_linha() + f->get_rm();
	int y_mov_min = f->get_coluna() - f->get_rm();
	int y_mov_max = f->get_coluna() + f->get_rm();

	/*VERIFICACAO SE EXISTE PELO MENOS 1 INIMIGO*/
	for(int i=x_mov_min;i<=x_mov_max;++i){
		for (int j = y_mov_min; j <= y_mov_max; ++j) {
			if (f->encontrei_inimiga(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
				return true;
			}
		}
	}
	return false;
}

bool Regrassacrificar::formiga_amiga_no_raio_movimento(Formigas *f) {

	/*POSICOES INICIAIS DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*VERTICES DO RAIO DE MOVIMENTO DA FORMIGA*/
	int x_mov_min = f->get_linha() - f->get_rm();
	int x_mov_max = f->get_linha() + f->get_rm();
	int y_mov_min = f->get_coluna() - f->get_rm();
	int y_mov_max = f->get_coluna() + f->get_rm();

	/*VERIFICACAO SE EXISTE PELO MENOS 1 INIMIGO*/
	for (int i = x_mov_min; i <= x_mov_max; ++i) {
		for (int j = y_mov_min; j <= y_mov_max; ++j) {
			if (f->encontrei_amiga(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
				return true;
			}
		}
	}
	return false;
}

int Regrassacrificar::formiga_amiga_menos_energia(Formigas *f, vector<int> x_amigas, vector<int> y_amigas) {

	if (x_amigas.size() == 1 && y_amigas.size() == 1) {
		return 0;//retorna a posicao onde se encontra que � a 1-->0
	}
	
	/*VETOR ONDE IRAO SER GUARDADAS AS ENERGIAS DAS FORMIGAS AMIGAS*/
	vector<int> energias;

	//cout << "\ntrack1\n";

	/*VERIFICACAO DA ENERGIA DAS FORMIGAS E COLOCACAO NO VETOR*/
	for (int i = 0; i < x_amigas.size(); ++i) {
		for (int j = 0; j < y_amigas.size(); ++j) {
			if (i == j) {
				energias.push_back(f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_energia_det_formiga(x_amigas[i], y_amigas[j]));
			}
		}
	}

	//cout << "\ntrack2\n";

	/*VERIFICACAO DE QUAL A FORMIGA QUE POSSUI MENOS ENERGIA*/
	int pos = 0;
	int menor = energias[0];

	for (int i = 0; i < energias.size(); ++i) {
		if (energias[i] < menor) {
			menor = energias[i];
			pos = i;
		}
	}
	return pos;
}

bool Regrassacrificar::condicao_regra(Formigas *f) {
	if (this->formiga_amiga_no_raio_movimento(f) == true && this->formiga_inimiga_no_raio_movimento(f) == true) {
		return true;
	}
	return false;
}

void Regrassacrificar::executa_regra(Formigas *f) {

	/*POSICOES INICIAIS DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*VERTICES DO RAIO DE MOVIMENTO DA FORMIGA*/
	int x_mov_min = f->get_linha() - f->get_rm();
	int x_mov_max = f->get_linha() + f->get_rm();
	int y_mov_min = f->get_coluna() - f->get_rm();
	int y_mov_max = f->get_coluna() + f->get_rm();

	/*VETORES ONDE SAO ARMAZENADAS AS FORMIGAS AMIGAS E AS INIMIGAS*/
	vector<int> x_amigas;
	vector<int> y_amigas;
	vector<int> x_inimigas;
	vector<int> y_inimigas;

	/*COLOCACAO DAS FORMIGAS EXISTENTES NO RAIO DE MOVIMENTO NOS VETORES*/
	for (int i = x_mov_min; i <= x_mov_max; ++i) {
		for (int j = y_mov_min; j <= y_mov_max; ++j) {
			if (f->encontrei_amiga(i, j)==true && (i != f->get_linha() || j != f->get_coluna())) {
				x_amigas.push_back(i);
				y_amigas.push_back(j);
			}
			if (f->encontrei_inimiga(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
				x_inimigas.push_back(i);
				y_inimigas.push_back(j);
			}
		}
	}

	/*POSICAO NO VETOR ONDE SE ENCONTRA A FORMIGA INIMIGA COM MAIS ENERGIA*/
	int pos_inimiga = Regras::qual_formiga_tem_mais_energia(f, x_inimigas, y_inimigas);

	/*POSICAO NO VETOR ONDE SE ENCONTRA A FORMIGA AMIGA COM MENOS ENERGIA*/
	int pos_amiga = this->formiga_amiga_menos_energia(f, x_amigas, y_amigas);

	//cout << "\ntrack3\n";

	/*ENERGIA DA FORMIGA AMIGA*/
	int energia_amiga = f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_energia_det_formiga(x_amigas[pos_amiga], y_amigas[pos_amiga]);

	//cout << "\ntrack4\n";

	/*A FORMIGA MATA A FORMIGA AMIGA E A INIMIGA*/
	//cout << "\nsdsdsd\n";

	f->retorna_minha_comunidade()->retorna_tela_comunidade()->remove_formigas_det_comunidade(x_inimigas[pos_inimiga], y_inimigas[pos_inimiga]);
	f->retorna_minha_comunidade()->retorna_tela_comunidade()->remove_formigas_det_comunidade(x_amigas[pos_amiga], y_amigas[pos_amiga]);
	//cout << "\ntrack5\n";

	/*REDUCAO EM 25% DA SUA ENERGIA, DE ACORDO COM A ENERGIA DA FORMIGA AMIGA*/
	int nova_energia = f->get_energia() - (energia_amiga*0.25);
	f->move_energia(nova_energia);

	//cout << "\ntrack6\n";
	//cout << "\ntrack10\n";
}