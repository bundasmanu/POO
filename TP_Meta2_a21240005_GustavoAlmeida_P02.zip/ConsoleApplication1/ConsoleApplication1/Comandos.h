#pragma once
#ifndef COMANDOS_H
#define COMANDOS_H
#include<iostream>
#include<string>
#include<vector>
#include<sstream>
#include<fstream>
#include<random>
#include<time.h>
/*Ver informacao no cpp Gestor-->estao l� apresentadas as minhas d�vidas*/
#include "Tela.h"
#include "Desenho.h"

using namespace std;

class Comandos {
	Tela *t;//tela default
	Desenho k;
	vector<string> c = { "defmundo","defen","defpc","defmi","defme","defnm"};//vetor com os comandos que sao necessarios para iniciar a configuracao
	vector<Tela*>copias;
	int contador = 0;
	int n;//numero de migalhas iniciais a serem criadas
public:
	Comandos();
	~Comandos();
	bool apaga_string_vec(string);
	bool apenas_digitos(string);
	int get_contador() const;//importante para saber quando posso passar para a fase de simulacao
	int get_n() const;
	int get_tamanho_tela() const;
	void executa(string);//comando executa
	void defmundo(int);//comando que define os limites da tela
	void defen(int);
	void defpc(int);
	void defvt(int);
	void defmi(int);
	void defme(int);
	void defnm(int);
	void cria_ninho(int, int);
	void cria_f(char, int,int,int);
	void cria_1(char, int, int, int);
	void migalha(int, int);
	void energninho(int, int);
	void energformiga(int, int, int);
	void mata(int, int);
	void inseticida(int);
	void lista_mundo();
	void lista_ninho(int);
	void lista_por_posicao(int, int);
	void tempo();//atualiza elementos na tela
	void desenha();//desenha elementos da tela
	bool grava_ficheiro(string);//retorna true-->correu bem e 0-->correu mal
	bool muda_ficheiro(string);
	bool apaga_ficheiro(string);//apaga ficheiro
	int gera_numero_aleatorio(int);//numero maximo fixado para a geracao do numero aleatorio
	void gera_numeros_aleatorios_formigas(int *);
	int* gera_numeros_aleatorio(int x[]);
};

#endif // !COMANDOS_H

