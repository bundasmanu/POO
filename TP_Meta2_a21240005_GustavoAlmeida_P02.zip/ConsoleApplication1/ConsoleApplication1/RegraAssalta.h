#pragma once
#ifndef REGRAASSALTA_H
#define REGRAASSALTA_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraAssalta : public Regras{

public:
	RegraAssalta();
	~RegraAssalta();
	bool Formigas_inimigas_raio_movimento(Formigas *f);
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraAssalta(*this); }
};

#endif // !REGRAASSALTA_H

