#include "Regras.h"
#include "Comunidade.h"
#include "Tela.h"

Regras::Regras() {

}

Regras::~Regras() {

}

void Regras::set_tela(Tela *t) {
	this->te = t;
}

bool Regras::verifica_formiga_inimiga_raio_visao(Formigas *f) {
	/*Para a formiga passada por parametro verifico o seu raio de visao,
	mediante esse raio, verifico para cada posicao se encontro uma formiga inimiga,
	se encontrar retorno true, sen�o retorno false*/

	/*OBTENCAO DA POSICAO DA FORMIGA E DO SEU RAIO DE VISAO*/
	int raio_visao_formiga = f->get_rv();
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*POSICOES QUE PODEM SER VISUALIZADAS PELA FORMIGA*/
	int x_max_vis = x_inicio + f->get_rv();
	int x_min_vis = x_inicio - f->get_rv();
	int y_min_vis = y_inicio - f->get_rv();
	int y_max_vis = y_inicio + f->get_rv();

	/*PERCORRER AS POSICOES PARA AS QUAIS A FORMIGA PODE ACEDER*/
	for (int i = x_min_vis; i < x_max_vis; ++i) {
		for (int j = y_min_vis; j < y_max_vis; ++j) {
			if (f->encontrei_inimiga(i, j) == true && (i!=f->get_linha() || j!=f->get_coluna())) {
				//cout << i << j << endl;
				return true;
			}
		}
	}
	return false;
}

int Regras::qual_formiga_tem_mais_energia(Formigas *f, vector<int> x_inimiga, vector<int> y_inimiga) {
	/*A formiga pergunta a Tela qual a energia de cada formiga inimiga, colocando esses
	valores num vetor, no final analisa esses valores e retorna a posicao da formiga com mais
	energia no vetor*/

	/*VETOR QUE GUARDA AS ENERGIAS DAS FORMIGAS INIMIGAS*/
	vector<int> energias;
	int posicao = 0;

	//cout << "\nx\n";

	/*PERCORRER AS FORMIGAS INIMIGAS E COLOCAR NO VETOR A SUA ENERGIA*/
	for (size_t i = 0; i < x_inimiga.size(); ++i) {
		for (size_t j = 0; j < y_inimiga.size(); ++j) {
			if (i == j) {/*ANALISA CADA FORMIGA INIMIGA(X E Y)*/
				energias.push_back(f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_energia_det_formiga(x_inimiga[i], y_inimiga[j]));//energia de uma determinada formiga
			}
		}
	}

	/*VERIFICAR QUAL A FORMIGA INIMIGA QUE POSSUI UMA ENERGIA MAIOR*/
	int pos = 0;/*GUARDA A POSICAO ONDE SE ENCONTRA A FORMIGA COM MAIS ENERGIA*/
	int maior = energias[0];

	for (size_t i = 0; i < energias.size(); ++i) {
		if (energias[i] > maior) {
			maior = energias[i];
			pos = i;
		}
	}
	//cout << pos << endl;
	return pos;
}

int Regras::qual_migalha_tem_mais_energia(Formigas *f, vector<int> x_migalhas, vector<int> y_migalhas) {
	/*percorro todas as migalhas, e coloco a energia que possuem num vetor, depois
	percorro esse vetor e retorno a posicao no vetor que tem a migalha com mais energia*/

	int pos2 = 0;

	/*VERIFICACAO SE EXISTE APENAS 1 MIGALHA*/
	if (x_migalhas.size() <= 1) {
		pos2=0;/*retorna posicao do unico elemento*/
		return pos2;
	}

	/*VETOR COM AS ENERGIAS DE CADA MIGALHA*/
	vector<int> energia_migalhas;

	/*POSICAO INCREMENTADA NO VETOR*/
	int pos = 0;

	/*PERCORRER TODAS AS MIGALHAS*/
	for (size_t i = 0; i < x_migalhas.size(); ++i) {
		for (size_t j = 0; j < y_migalhas.size(); ++j) {
			if (i == j) {/*VERIFICACAO DE CADA MIGALHA*/
				int x = f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_energia_migalha(x_migalhas[i], y_migalhas[j]);
				//cout << x;
				energia_migalhas.push_back(x);
				pos++;
			}
		}
	}

	/*POSICAO MIGALHA MAIS ENERGIA E VARIAVEL QUE CONTROLA O MAIOR*/
	int maior = energia_migalhas[0];

	/*VERIFICACAO QUAL A MIGALHA QUE CONTEM MAIS ENERGIA*/
	for (size_t i = 0; i < energia_migalhas.size(); ++i) {
		if (energia_migalhas[i] > maior) {
			maior = energia_migalhas[i];
			pos2 = i;
		}
	}
	return pos2;
}


vector<int> Regras::aproximacao_formiga_inimiga_ou_migalha(Formigas *f, int posicao_x_inimiga, int posicao_y_inimiga) {
	/*Mediante a posicao da formiga e da formiga inimiga, necessito de deslocar a formiga,
	no sentido da formiga inimiga, ou seja desloca-la de acordo com o seu x e y*/

	/*OU SEJA TRATA-SE DO RACIOCINIO INVERSO A REGRA FOGE*/
	/*EXISTEM TAMBEM 4 SITUACOES E O OBJECTIVO E QUE A FORMIGA SE DESLOQUE PARA O MSM "QUADRANTE" ONDE SE ENCONTRA A FORMIGA INIMIGA*/

	/*VETOR QUE IRA CONTER AS POSICOES PARA ONDE A FORMIGA SE PODE DESLOCAR DE MODO A SE APROXIMAR DA FORMIGA INIMIGA, MEDIANTE O SEU RAIO DE MOVIMENTO*/
	vector<int>x_aproximacao;
	vector<int>y_aproximacao;

	if (posicao_x_inimiga >= f->get_linha() && posicao_y_inimiga >= f->get_coluna()) {/*1 SITUACAO*/
		for (int i = f->get_linha(); i <= f->get_linha() + f->get_rm(); ++i) {
			for (int j = f->get_coluna(); j <= f->get_coluna() + f->get_rm(); ++j) {
				if (f->posso_andar(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {/*PARA NAO VALIDAR A SUA POSICAO*/
					x_aproximacao.push_back(i);
					y_aproximacao.push_back(j);
				}
			}
		}
	}

	if (posicao_x_inimiga <= f->get_linha() && posicao_y_inimiga <= f->get_coluna()) {/*2 SITUACAO*/
		for (int i = f->get_linha() - f->get_rm(); i <= f->get_linha(); ++i) {
			for (int j = f->get_coluna() - f->get_rm(); j <= f->get_coluna(); ++j) {
				if (f->posso_andar(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
					x_aproximacao.push_back(i);
					y_aproximacao.push_back(j);
				}
			}
		}
	}

	if (posicao_x_inimiga >= f->get_linha() && posicao_y_inimiga <= f->get_coluna()) {/*3 SITUACAO*/
		for (int i = f->get_linha(); i <= f->get_linha() + f->get_rm(); ++i) {
			for (int j = f->get_coluna() - f->get_rm(); j <= f->get_coluna(); ++j) {
				if (f->posso_andar(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
					x_aproximacao.push_back(i);
					y_aproximacao.push_back(j);
				}
			}
		}
	}

	if (posicao_x_inimiga<=f->get_linha() && posicao_y_inimiga>=f->get_coluna()) {/*4 SITUACAO*/
		for (int i = f->get_linha() - f->get_rm(); i <= f->get_linha(); ++i) {
			for (int j = f->get_coluna(); j <= f->get_coluna() + f->get_rm(); ++j) {
				if (f->posso_andar(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
					x_aproximacao.push_back(i);
					y_aproximacao.push_back(j);
				}
			}
		}
	}

	/*GERACAO DA POSICAO APROXIMADA ALEATORIA*/
	vector<int> posicao_nova_formiga;

	/*CASO NAO HAJAM POSICOES OPOSTAS PARA IR, ESTAO TODAS OCUPADAS, PERMANECO NA MESMA POSICAO*/
	if (x_aproximacao.size() == 0 && y_aproximacao.size() == 0) {
		posicao_nova_formiga.insert(posicao_nova_formiga.begin() + 0, f->get_linha());
		posicao_nova_formiga.insert(posicao_nova_formiga.begin() + 1, f->get_coluna());
	}
	else {
		std::default_random_engine generator((unsigned int)time(0));
		std::uniform_int_distribution<int> distribution(0, x_aproximacao.size()-1);//retorna uma posicao aleatoria
		int posicao_aleatoria = distribution(generator);//gero numero aleatorio de uma das posicoes do vetor de posicoes permitidas opostas
		posicao_nova_formiga.insert(posicao_nova_formiga.begin()+0, x_aproximacao[posicao_aleatoria]);
		posicao_nova_formiga.insert(posicao_nova_formiga.begin() + 1, y_aproximacao[posicao_aleatoria]);
	}

	return posicao_nova_formiga;

}

vector<int> Regras::move_direccao_oposta_formiga_inimiga(Formigas *f, int x_inimiga, int y_inimiga) {
	/*EXISTEM 4 SITUACOES PARA UMA FORMIGA SE DESLOCAR NA DIRECCAO OPSTA:
	1-FORMIGA INIMIGA POSSUI X E Y SUPERIORES � FORMIGA, ENTAO A FORMIGA DESLOCA-SE PARA X E Y INFERIORES � SUA POSICAO ATUAL
	2-FORMIGA INIMIGA POSSUI X E Y INFERIORES � FORMIGA, ENTAO A FORMIGA DESLOCA-SE PARA X E Y SUPERIORES � SUA POSICAO ATUAL
	3-FORMIGA INIMIGA POSSUI X SUPERIOR E Y INFERIOR, ENTAO A FORMIGA DESLOCA-SE PARA X INFERIOR A SUA POSICAO E Y SUPERIOR
	4-FORMIGA INIMIGA POSSUI Y SUPERIOR E X INFERIOR, ENTAO A FORMIGA DESLOCA-SE PARA X SUPERIOR A SUA POSICAO E Y INFERIOR*/

	/*VETOR QUE GUARDA AS POSICOES OPOSTAS PARA AS QUAIS A FORMIGA SE PODE DESLOCAR*/
	vector<int>posicao_oposta_x;
	vector<int>posicao_oposta_y;

	if (x_inimiga >= f->get_linha() && y_inimiga >= f->get_coluna()) {/*1-SITUACAO*/
																	//VERIFICO SE EXISTEM POSICOES PARA ONDE POSSO IR, SE ESTIVER TUDO OCUPADO PERMANECO NA MSM POSICAO
		for (int i = f->get_linha() - f->get_rm(); i <= f->get_linha(); ++i) {/*PERCORRO O MEU RAIO DE MOVIMENTO*/
			for (int j = f->get_coluna() - f->get_rm(); j <= f->get_coluna(); ++j) {
				if ((j != f->get_coluna() || i != f->get_linha()) && f->posso_andar(i, j) == true) {
					posicao_oposta_x.push_back(i);
					posicao_oposta_y.push_back(j);
				}
			}
		}
	}

	if (x_inimiga <= f->get_linha() && y_inimiga <= f->get_coluna()) {/*2 SITUACAO*/
		for (int i = f->get_linha(); i <= f->get_linha() + f->get_rm(); ++i) {
			for (int j = f->get_coluna(); j <= f->get_coluna() + f->get_rm(); ++j) {
				if ((i != f->get_linha() || j != f->get_coluna()) && f->posso_andar(i, j) == true) {
					posicao_oposta_x.push_back(i);
					posicao_oposta_y.push_back(j);
				}
			}
		}
	}

	if (x_inimiga >= f->get_linha() && y_inimiga <= f->get_coluna()) {/*3 SITUACAO*/
		for (int i = f->get_linha() - f->get_rm(); i <= f->get_linha(); ++i) {
			for (int j = f->get_coluna(); j <= f->get_coluna() + f->get_rm(); ++j) {
				if ((i != f->get_linha() || j != f->get_coluna()) && f->posso_andar(i, j) == true) {
					posicao_oposta_x.push_back(i);
					posicao_oposta_y.push_back(j);
				}
			}
		}
	}

	if (x_inimiga<=f->get_linha() && y_inimiga>=f->get_coluna()) {/*4 SITUACAO*/
		for (int i = f->get_linha(); i <= f->get_linha() + f->get_rm(); ++i) {
			for (int j = f->get_coluna() - f->get_rm(); j <= f->get_coluna(); ++j) {
				if ((i != f->get_linha() || j != f->get_coluna()) && f->posso_andar(i, j) == true) {
					posicao_oposta_x.push_back(i);
					posicao_oposta_y.push_back(j);
				}
			}
		}
	}

	vector<int> posicao_nova_formiga;

	/*CASO NAO HAJAM POSICOES OPOSTAS PARA IR, ESTAO TODAS OCUPADAS, PERMANECO NA MESMA POSICAO*/
	if (posicao_oposta_x.size() == 0 && posicao_oposta_y.size() == 0) {
		posicao_nova_formiga.push_back(f->get_linha());
		posicao_nova_formiga.push_back(f->get_coluna());
	}

	else {
		std::default_random_engine generator((unsigned int)time(0));
		std::uniform_int_distribution<int> distribution(0, posicao_oposta_x.size()-1);//retorna uma posicao aleatoria
		int posicao_aleatoria = distribution(generator);//gero numero aleatorio de uma das posicoes do vetor de posicoes permitidas opostas
		//cout << posicao_aleatoria << endl;
		posicao_nova_formiga.push_back(posicao_oposta_x[posicao_aleatoria]);
		posicao_nova_formiga.push_back(posicao_oposta_y[posicao_aleatoria]);
	}

	return posicao_nova_formiga;
}
