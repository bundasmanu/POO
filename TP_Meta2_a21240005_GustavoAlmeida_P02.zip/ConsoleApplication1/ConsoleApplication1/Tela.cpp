#include "Tela.h"

Tela::Tela(int n_l,string no){
	this->n_linhas = n_l;
	this->n_colunas = n_l;
	this->tam = (n_l * 2);
	this->contador_iteracoes = 0;
	this->nome = no;
	//as regras sao aplicadas de acordo com as caracteristicas desta tela
}

Tela::~Tela() {
	//necessito de apagar o vetor de Comunidades
	//o vetor de migalhas ainda nao se encontra presente
	if (this->c.size() > 0) {
		vector<Comunidade*>::iterator i = this->c.begin();
		while (i != this->c.end()) {
			delete(*i);
			i = this->c.erase(i);
		}
	}
	//apagar o vetor de migalhas
	if (this->m.size() > 0) {
		vector<Migalhas*>::iterator i = this->m.begin();
		while (i != this->m.end()) {
			delete(*i);
			i = this->m.erase(i);
		}
	}
}

int Tela::get_linhas() const {
	return this->n_linhas;
}

int Tela::get_colunas() const {
	return this->n_colunas;
}

void Tela::acrescenta_comunidade(int n_l, int n_c) {//confirmar isto
	if (this->posicao_vazia(n_l, n_c) == true && this->verifica_limites(n_l, n_c) == true) {//apenas acrescenta se estiver vazia e se respeitar os limites
		this->c.push_back(new Comunidade(n_l, n_c));
		this->c.back()->set_tela(this);//dizer a comunidade, que pertence a este mundo-->confirmar
		cout << "\nNinho criado com sucesso\n";
	}
	else {
		cout << "Nao foi possivel criar o ninho-- defina valores permitidos" << endl;
	}
}

bool Tela::remover_comunidade(int n_ninho) {//confirmar isto//-->comando inseticida
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->get_nserie_ninho() == n_ninho) {
			delete (*i);
			i = this->c.erase(i);
			return true;
		}
		++i;
	}
	return false;
}

bool Tela::procura_comunidade(int n_ninho) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->get_nserie_ninho() == n_ninho) {
			return true;
		}
		else {
			++i;
		}
	}
	//se cheguei aqui � porque nao encontrei
	return false;
}

bool Tela::procura_comunidade(int l, int c) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->get_linha_ninho() == l && (*i)->get_coluna_ninho() == c) {
			return true;
		}
		else {
			++i;
		}
	}
	//se cheguei aqui nao encontrei
	return false;
}

bool Tela::posicao_vazia(int l, int c) {/*Confirmar o Posicao Vazia*/
	//ainda estou a verificar apenas para as comunidades,ainda nao tem migalhas
	int w = 0;
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true || this->procura_comunidade(l, c) == true) {//se nao existir nada na posicao return true
			w++;
		}
		++i;
	}

	/*Encontrei uma formiga ou um ninho*/
	if (w > 0) {
		return false;
	}

	vector<Migalhas*>::iterator j = this->m.begin();
	if (w == 0) {
		while (j != this->m.end()) {
			if ((*j)->get_linha() == l && (*j)->get_coluna() == c){
				return false;
			}
			++j;
		}
	}
	//cout << "\nentradaposso1\n";
	//se cheguei � porque a posicao estava vazia
	return true;
}

bool Tela::posso_posicionar_formiga(int l, int c, int n_ni) {
	//neste momento apenas se consideram comunidades e ainda nao migalhas

	//se a posicao estiver vazia tudo bem
	if (this->posicao_vazia(l, c) == true) {//se a posicao estiver vazia pode vaguear
		return true;
	}

	vector<Comunidade*>::iterator i=this->c.begin();
	while (i != this->c.end()) {//percorro todas as comunidades
		if ((*i)->procura_formiga(l, c) == true || ((*i)->get_linha_ninho() == l && (*i)->get_coluna_ninho() == c && (*i)->get_nserie_ninho()!=n_ni)) {//se numa comunidade uma formiga tiver nessa posicao, ou se tiver l� um ninho e nao for o da formiga, pronto nao posso ir para essa posicao
			return false;
		}
		else {
			++i;
		}
		//dps tambem tenho de verificar as migalhas
	}
	return true;
}

bool Tela::verifica_limites(int l, int c) {
	if (l > 10 && l < 10 + this->get_linhas()+1 && c > 10 && c < 10 + this->get_linhas()+1) {
		return true;
	}
	return false;
}

void Tela::acrescenta_formigas_det_comunidade(char tp, int n_ni, int l, int c){
	//nao � necessario verificar os limites da tela, visto que os numeros aleatorios sao gerados de acordo com os limites da tela
	/*IMPORTANTE*/
	//se inserir o comando criaf-->quando gero os numeros aleatorio garanto que a posicao esta msm vazia
	//se inserir no ninho ou numa posicao definida pelo utilizador, recorro ao metodo posso_posicionar_formiga, que me permite definir se uma formiga respeita aquilo que se pretende
	vector<Comunidade*>::iterator i;
	if ((this->posicao_vazia(l, c) == true || this->posso_posicionar_formiga(l,c,n_ni)==true) && this->c.size()>0 && this->procura_comunidade(n_ni)==true && this->verifica_limites(l,c)==true) {//assim posso inserir uma formiga numa posicao vazia ou no ninho
		for (i = this->c.begin(); i != this->c.end(); ++i) {
			if ((*i)->get_nserie_ninho() == n_ni) {
				(*i)->acrescenta_formigas(tp, n_ni, l, c);
				//return;
			}
		}
		cout << "\nFormiga adicionadas com sucesso\n";
	}
	else if(this->verifica_limites(l, c) == false){
		cout << "Limites nao sao validos" << endl;
	}
	else if (this->c.size() == 0 || this->procura_comunidade(n_ni) == false) {
		cout << "Comunidade mencionada nao � valida" << endl;
	}
	else {
		cout << "Nao pode adicionar nessa posicao" << endl;
	}
}

bool Tela::remove_formigas_det_comunidade(int l, int c) {
	/*listo todas as comunidades existentes na Tela, e verifico 
	se encontro uma formiga naquela posicao, se encontrar digo �
	comunidade a que pertence, que a remova*/
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true) {
			(*i)->remove_formiga(l, c);
			return true;
		}
		++i;
	}
	return false;
}

bool Tela::procura_formiga_det_comunidade(int l, int c) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true) {
			return true;
		}
		++i;
	}
	return false;
}

int Tela::get_ninho_det_formiga_det_comunidade(int l, int c) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true) {
			return (*i)->get_nserie_ninho();
		}
		++i;
	}
	return 0;//vai encontrar sempre primeiro, visto que antes procuro se existe a formiga
}

string Tela::lista_mundo() {
	//apenas listo por agora as comunidades e nao os ninhos
	ostringstream frase;
	for (size_t i = 0; i < this->c.size(); ++i) {
		frase << this->c[i]->lista_ninho_comunidade();
		frase << "Numero de formigas: " << this->c[i]->numero_formigas()<<"\n";
	}

	//migalhas
	for (size_t i = 0; i < this->m.size(); ++i) {
		frase << this->m[i]->Obtem_info()<<"\n";
	}

	return frase.str();
}

string Tela::lista_por_posicao_tela(int l, int c) {
	//lista todos os elementos presentes numa determinada linha e coluna
	//neste momento apenas temos inerente aqui o conceito de comunidades e ainda n�o de migalhas
	ostringstream frase;
	int x = 0;
	int y = 0;
	//elementos da comunidade, verificacao
	for (size_t i = 0; i < this->c.size(); ++i) {
		if (this->c[i]->procura_formiga(l, c) == true) {
			frase << this->c[i]->lista_formiga(l, c);
			x++;
		}
		if (this->procura_comunidade(l,c)==true) {
			frase << this->c[i]->lista_ninho_comunidade();
			x++;
		}
	}

	//migalhas verificacao
	for (size_t i = 0; i < this->m.size(); ++i) {
		if (this->m[i]->get_linha() == l && this->m[i]->get_coluna() == c) {
			frase << this->m[i]->Obtem_info();
			y++;
		}
	}

	if (x == 0 && y==0 && this->verifica_limites(l,c)==true) {
		frase << "Posicao encontra-se vazia.\n";
	}
	else if (x == 0 && this->verifica_limites(l, c) == false) {
		frase << "Posicao indicada nao se enquadra nos limites da tela\n";
	}
	return frase.str();
}

string Tela::lista_por_comunidade(int n) {
	vector<Comunidade*>::iterator i=this->c.begin();
	ostringstream frase;
	while (i != this->c.end()) {
		if ((*i)->get_nserie_ninho() == n) {
			return (*i)->lista_comunidade();
		}
		else {
			++i;
		}
	}
	//se cheguei aqui nao encontrei
	frase << "Nao existe o ninho indicado" << endl;
	return frase.str();
}

//metodo que atualiza os elementos presentes na tela
void Tela::atualiza_elementos_tela(int max) {
	//neste momento apenas temos comunidades e ainda nao temos presente as migalhas
	if (this->c.size() > 0) {
		vector<Comunidade*>::iterator i = this->c.begin();
		while (i != this->c.end()) {
			(*i)->atualiza_elementos_comunidade();
			++i;
		}
		cout << "\nElementos da tela foram atualizados\n";
	}
	else {
		cout << "\nNao havia nada para atualizar\n";
	}
	
	/*Modificacao migalhas*/
	/*Necessario 1� tirar 1 de energia �s formigas que j� existem
	2� gerar novas formigas-->mediante o valor gerado
	3� verificar energia das migalhas, as migalhas � que pedem ao mundo que a retirem*/
	vector<Migalhas*>::iterator i = this->m.begin();
	while (i != this->m.end()) {
		(*i)->move_energia((*i)->get_energia() - 1);
		++i;
	}

	//cout << "\nbum0\n";

	for (size_t i = 0; i < this->m.size(); ++i) {
		this->m[i]->verifica_energia();//depois de retirar a energia �s migalhas � necess�rio verificar a sua quantidade de energia
	}

	//cout << "\nbum1\n";

	/*Falta fazer a geracao de novas formigas*/
	for (int i = 0; i < max; ++i) {
		int n[2];
		this->m[i]->posicao_vazia_aleatoria(n);
		this->acrescenta_migalha(n[0],n[1]);
	}

	//cout << "\nbum2\n";

	/*Aumenta a variav�l que controla o n�mero de itera��es que foram efetuadas at� ent�o*/
	this->contador_iteracoes++;
}

void Tela::desenha_tela() {
	//ainda nao tenho presente as migalhas, apenas as comunidades
	int cor = 1;
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		(*i)->desenha_comunidade(cor);
		++i;
		++cor;//incrementa a cor de cada comunidade
	}
	//desenhar agora as migalhas
	vector<Migalhas*>::iterator j = this->m.begin();
	while (j != this->m.end()) {
		(*j)->desenha_migalha();
		++j;
	}
}

void Tela::acrescenta_migalha(int l, int c) {
	this->m.push_back(new Migalhas(this->energia_migalha, l, c));
	//confirmar dps isto aqui
	this->m.back()->set_tela(this);//diz � migalha ao mundo � qual pertence
	cout << "\nInseri migalha no mundo\n";
}

void Tela::remove_migalha(int l, int c) {
	vector<Migalhas*>::iterator i = this->m.begin();
	while (i != this->m.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			delete (*i);
			i = this->m.erase(i);
			return;
		}
		++i;
	}
}

bool Tela::procura_migalha(int l, int c) {
	vector<Migalhas*>::iterator i = this->m.begin();
	while (i != this->m.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			return true;
		}
		++i;
	}
	return false;
}

void Tela::acrescenta_energia_ninho_det_comunidade(int n_ni, int acresc_e) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->get_nserie_ninho() == n_ni) {
			(*i)->acrescenta_energia_ninho(acresc_e);
			cout << "\nEnergia acrescentada\n";
			return;
		}
		++i;
	}
	cout << "\nNao encontrei o ninho\n";
}

void Tela::acrescenta_energia_formiga_det_comunidade(int l, int c, int acresc_e) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true) {
			(*i)->acrescenta_energia_formiga(l, c, acresc_e);
			cout << "\nEnergia acrescentada\n";
			return;
		}
		++i;
	}
	cout << "\nNao encontrei a formiga\n";
}

void Tela::set_energia_migalhas(int n) {
	energia_migalha = n;
}

void Tela::set_percentagem_migalhas_iniciais(int n) {
	percentagem_migalhas_iniciais=n;
}

void Tela::set_migalhas_cada_instante(int n) {
	migalhas_cada_instante = n;
}

Formigas * Tela::retorna_formiga_det_comunidade(int l, int c) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true) {
			return (*i)->retorna_formiga_da_comunidade(l, c);
		}
		++i;
	}
	return NULL;
}

int Tela::retorna_energia_det_formiga(int l, int c) {
	vector<Comunidade*>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if ((*i)->procura_formiga(l, c) == true) {
			return (*i)->get_energia_formiga(l, c);
		}
		++i;
	}
	return 0;
}

int Tela::retorna_energia_migalha(int l, int c) {
	vector<Migalhas*>::iterator i = this->m.begin();
	while (i != this->m.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			return (*i)->get_energia();
		}
		++i;
	}
	return 0;
}

void Tela::move_energia_det_migalha(int energia,int l, int c) {
	vector<Migalhas*>::iterator i = this->m.begin();
	while (i != this->m.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			(*i)->move_energia(energia);
		}
		++i;
	}
}

int Tela::get_numero_iteracoes() const {
	return this->contador_iteracoes;
}

int Tela::get_migalhas_cada_instante() const {
	return this->migalhas_cada_instante;
}

Migalhas * Tela::retorna_migalha(int l, int c) {
	vector<Migalhas*>::iterator i = this->m.begin();
	while (i != m.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			return (*i);
		}
		++i;
	}
	return NULL;
}

Tela::Tela(const Tela &t) {
	/*necessito de fazer uma copia da tela passada por argumento, para a tela que invocou o construtor por copia*/

	for (size_t j = 0; j < t.m.size(); ++j) {
		this->m.push_back(new Migalhas(*t.m[j]));
		m[j]->set_tela(this);
	}

	for (size_t i = 0; i < t.c.size(); ++i) {
		this->c.push_back(new Comunidade(*t.c[i]));
		c[i]->set_tela(this);
	}

	this->contador_iteracoes = t.contador_iteracoes;
	this->n_linhas = this->n_colunas = t.n_linhas;
	this->tam = t.tam;
	this->energia_migalha = t.energia_migalha;
	this->percentagem_migalhas_iniciais = t.percentagem_migalhas_iniciais;
	this->migalhas_cada_instante = t.migalhas_cada_instante;
	this->nome = t.nome;
}

Tela & Tela::operator=(const Tela &t) {
	/*1-necessito de apagar o conteudo existente na Tela
	2-depois copiar o conteudo para a Tela que invocou o operador de atribuicao*/

	/*apagar as comunidades existentes*/
	for (size_t i = 0; i < this->c.size(); ++i) {
		delete this->c[i];
	}
	this->c.clear();

	/*apagar as migalhas existentes*/
	for (size_t j = 0; j < this->m.size(); ++j) {
		delete this->m[j];
	}
	this->m.clear();

	/*agora basta copiar o conteudo para a Comunidade*/
	this->n_linhas = this->n_colunas = t.n_linhas;
	this->tam = t.tam;
	this->energia_migalha = t.energia_migalha;
	this->migalhas_cada_instante = t.migalhas_cada_instante;
	this->percentagem_migalhas_iniciais = t.percentagem_migalhas_iniciais;
	this->nome = t.nome;

	/*copia das comunidades da tela passada por argumento para a tela*/
	for (size_t i = 0; i < t.c.size(); ++i) {
		this->c.push_back(new Comunidade(*t.c[i]));
		c[i]->set_tela(this);
	}

	/*copia das migalhas da tela passada por argumento para a tela*/
	for (size_t j = 0; j < t.m.size(); ++j) {
		this->m.push_back(new Migalhas(*t.m[j]));
		m[j]->set_tela(this);
	}

	return (*this);
}

int Tela::energia_migalha = 0;
int Tela::percentagem_migalhas_iniciais=0;
int Tela::migalhas_cada_instante = 0;