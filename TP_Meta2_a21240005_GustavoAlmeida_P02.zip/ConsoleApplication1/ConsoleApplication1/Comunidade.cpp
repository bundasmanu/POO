#include "Comunidade.h"
#include "Tela.h"
#include "RegraFoge.h"
#include "RegraPersegue.h"
#include "RegraAssalta.h"
#include "RegraProtege.h"
#include "RegraProcuraMigalha.h"
#include "RegraComeMigalha.h"
#include "RegraVaiParaNinho.h"
#include "RegraSacrificar.h"
#include "RegraDestroiComida.h"

Comunidade::Comunidade(int n_l,int n_c) {
	this->m = new Ninho(n_l, n_c,energia_ninho);
	this->m->set_comunidade(this);//digo ao ninho que esta � a sua comunidade
	//tenho de fazer aqui o set do Ninho, para o ninho saber qual a sua comunidade
}

Comunidade::~Comunidade() {
	//tenho de fazer delete do ninho
	//tenho de fazer delete �s formigas da comunidade
	if (m != NULL) {
		delete m;
	}
	vector<Formigas*>::iterator i=this->f.begin();
	while (i != this->f.end()) {
		delete (*i);
		i = this->f.erase(i);
	}
}

void Comunidade::acrescenta_formigas(char tip, int n_ninho,int linha,int coluna) {
	if (tip == 'C' || tip == 'V' || tip == 'A' || tip == 'E' || tip == 'S') {
		if (tip == 'E') {//caso da Exploradora inicialmente
			//vector<Regras*> re;
			//re.push_back(new RegraFoge());
			this->f.push_back(new Exploradora(linha, coluna));//numero aleatorio aqui
		}
		if (tip == 'C') {
			this->f.push_back(new Cuidadora(linha, coluna));//numero aleatorio aqui
		}
		if (tip == 'V') {
			this->f.push_back(new Vigilante(linha, coluna));//numero aleatorio aqui
		}
		if (tip == 'A') {
			this->f.push_back(new Assaltante(linha, coluna));//numero aleatorio aqui
		}
		if (tip == 'S') {
			this->f.push_back(new Surpresa(linha, coluna));//numero aleatorio aqui
		}
				//fazer aqui set do ninho e da comunidade
				for (size_t i = 0; i < this->f.size(); ++i) {
					if (this->f[i]->get_linha() == linha && this->f[i]->get_coluna() == coluna) {
						this->f[i]->set_ninho(this->m);
						this->f[i]->set_comunidade(this);
					}
				}
		}
	else {//tentativa de adicionar um tipo de formigas nao existente
		return;
	}
}

void Comunidade::remove_formiga(int l, int c) {
	vector<Formigas*>::iterator i=this->f.begin();
	while (i != this->f.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			delete (*i);
			i = this->f.erase(i);
			return;
		}
			++i;
	}
}

void Comunidade::remove_ninho() {
	delete m;
}

bool Comunidade::procura_formiga(int l, int c) {
	for (size_t i = 0; i < this->f.size(); ++i) {
		if (this->f[i]->get_linha() == l && this->f[i]->get_coluna() == c) {
			return true;
		}
	}
	return false;
}

int Comunidade::get_nserie_ninho() {
	return this->m->get_nserie();
}

int Comunidade::get_linha_ninho() {
	return this->m->get_linha();
}

int Comunidade::get_coluna_ninho() {
	return this->m->get_coluna();
}

int Comunidade::get_energia_ninho() {
	return this->m->get_energia();
}

int Comunidade::get_energia_formiga(int l, int c) {
	vector<Formigas*>::iterator i = this->f.begin();
	while (i != this->f.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			return (*i)->get_energia();
		}
		++i;
	}
}

string Comunidade::lista_comunidade() {
	ostringstream frase;
	frase << " \nNinho: " << this->m->lista_ninho() << "\n";
	vector<Formigas*>::iterator i;
	for (i = this->f.begin(); i != this->f.end(); ++i) {
		frase<<(*i)->Obtem_info()<<"\n";
	}
	return frase.str();
}

string Comunidade::lista_ninho_comunidade() {
	return this->m->lista_ninho();
}

string Comunidade::lista_formiga(int l, int c) {
	vector<Formigas*>::iterator i = this->f.begin();
	while (i != this->f.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			return (*i)->Obtem_info();
		}
		else {
			++i;
		}
	}
	//se nao encontrei a formiga
	string x = "\nNao encontrei a formiga indicada nessa posicao\n";
	return x;
}

int Comunidade::numero_formigas() {
	if (this->f.empty()) {
		return 0;
	}
	return this->f.size();//retorna o tamanho do vetor
}

//atualizacao das formigas e ninho presentes dentro da comunidade
void Comunidade::atualiza_elementos_comunidade() {
	//aqui � necessario verificar se uma formiga esta no ninho se estiver entao chamo o metodo de atuar_no_ninho
	//se nao estou no ninho, aplico as regras relativas a cada tipo de formiga
	//no final as formigas verificam a energia que lhes resta
	//e necessito de decrementar 1 unidade a energia do ninho, caso nao esteja nenhuma formiga no ninho
	vector<Formigas*>::iterator i;
	int x, w=0;
	bool verdade;
	/*
	for (i = f.begin(); i != f.end();++i) {
		if ((*i)->estou_no_ninho() == true) {//se a formiga se encontra no ninho
			(*i)->atuar_quando_estou_no_ninho();
			w++;
		}
		else {//senao me encontro no ninho entao
			if ((*i)->get_energia()>0) {//uma formiga s� aplica o seu comportamento se tiver energia para tal//
				(*i)->Comportamento();
			}
		}
	}*/

	int tamanho = f.size();

	for (size_t i = 0; i < this->f.size(); ++i) {
		if (this->f[i]->estou_no_ninho() == true && this->f[i]->get_energia() > 0 && ((this->f[i]->get_energia()>(this->f[i]->get_energia_inicial())) || (this->f[i]->get_energia()<(this->f[i]->get_energia_inicial()*0.5) && this->m->get_energia()>10) ) ) {
			this->f[i]->atuar_quando_estou_no_ninho();
		}
		else {
			if (this->f[i]->get_energia() > 0) {
				this->f[i]->Comportamento();
			}
		}
		if (tamanho>f.size() && (i!=0)) {//para a regra sacrificar que ao eliminar o size fica -1, entao necessito de ir para a posicao -1
			if (i == NULL) {
				--i;
				tamanho = f.size();
			}
		}
		else {
			verdade = this->f[i]->verifica_energia();
			if (verdade == false) {
				i--;
			}
		}
		tamanho = f.size();
	}


	//verificacao da energia das formigas
	/*for (size_t i = 0; i < this->f.size(); ++i) {
		verdade = this->f[i]->verifica_energia();//a formiga verifica a sua energia
		cout << "\nVerdade: " << verdade << endl;
		if (verdade == false) {
			i = 0;
		}
	}

	cout << "\nhdhshdhs\n";*/

	//no final o ninho verifica a sua energia
	x = this->m->verifica_energia();
	if (x == 1) {//se o ninho esta vivo e ninguem esta no ninho, se nao entrar aqui o ninho morreu
		this->m->cria_nova_formiga();//cria uma nova formiga aleatoria na sua c�lula
	}
}

void Comunidade::desenha_comunidade(int cor) {
	this->m->desenha_ninho(cor);
	vector<Formigas*>::iterator i=this->f.begin();
	while (i != this->f.end()) {
		(*i)->desenha_formiga(cor);
		++i;
	}
}

void Comunidade::set_energia(int n) {
	energia_ninho = n;
}

void Comunidade::energia_defvt(int n) {
	valor_transf_form_nin = n;
}

int Comunidade::get_percentagem_defvt() const {
	return valor_transf_form_nin;
}

void Comunidade::percentagem_defpc(int n) {
	percentagem_nova_f = n;
}

int Comunidade::get_defpc() const {
	return this->percentagem_nova_f;
}

void Comunidade::set_tela(Tela *t) {
	this->tel = t;
}

void Comunidade::acabou_comunidade(int n) {
	if (this->get_energia_ninho() <= 1) {
		this->tel->remover_comunidade(n);
	}
}

void Comunidade::acrescenta_energia_ninho(int acresc_e) {
	this->m->move_energia(this->m->get_energia()+acresc_e);
}

void Comunidade::acrescenta_energia_formiga(int l, int c, int acresc_e) {
	vector<Formigas*>::iterator i = this->f.begin();
	while (i != this->f.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			(*i)->move_energia((*i)->get_energia() + acresc_e);
		}
		++i;
	}
}

Tela * Comunidade::retorna_tela_comunidade() {
	return this->tel;
}

Formigas * Comunidade::retorna_formiga_da_comunidade(int l, int c) {
	vector<Formigas*>::iterator i = this->f.begin();
	while (i != this->f.end()) {
		if ((*i)->get_linha() == l && (*i)->get_coluna() == c) {
			return (*i);
		}
		++i;
	}
	return NULL;
}

Comunidade::Comunidade(const Comunidade &c) {
	/*necessito de copiar os elementos que estao presentes na Comunidade passado por argumento,
	parar a Comunidade que invoca o construtor por copia*/
	this->m = new Ninho(*c.m);
	m->set_comunidade(this);
	this->energia_ninho = c.energia_ninho;
	this->percentagem_nova_f = c.percentagem_nova_f;
	this->valor_transf_form_nin = c.valor_transf_form_nin;

	/*copia das formigas presentes no vetor passado por argumento par a Comunidade*/
	for (size_t i = 0; i < c.f.size(); ++i) {
		this->f.push_back(c.f[i]->clone());
		f[i]->set_comunidade(this);
		f[i]->set_ninho(this->m);
	}

}

Comunidade & Comunidade::operator=(const Comunidade &c) {
	/*1-necessito de apagar o que se encontra na Comunidade
	2-depois � necessario atribuir os valores � Comunidade*/

	delete m;//apago o meu ninho
	delete tel;//apago a tela a que pertenco

	/*Apago as formigas*/
	for (size_t i = 0; i < this->f.size(); ++i) {
		delete this->f[i];
	}
	this->f.clear();

	/*Agora basta atribuir os valores � Comunidade*/
	this->m = new Ninho(*c.m);
	this->m->set_comunidade(this);
	//this->tel = c.tel;
	this->energia_ninho = c.energia_ninho;
	this->valor_transf_form_nin = c.valor_transf_form_nin;
	this->percentagem_nova_f = c.percentagem_nova_f;

	/*copia das formigas*/
	for (size_t i = 0; i < c.f.size(); ++i) {
		this->f.push_back(c.f[i]->clone());
		this->f[i]->set_ninho(this->m);
		this->f[i]->set_comunidade(this);
	}

	return (*this);
}

int Comunidade::energia_ninho = 0;
int Comunidade::percentagem_nova_f = 0;
int Comunidade::valor_transf_form_nin = 1;