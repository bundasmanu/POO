#pragma once
#ifndef TELA_H
#define TELA_H
#include<iostream>
#include<string>
#include<sstream>
#include<vector>
#include "Comunidade.h"
#include "Regras.h"
#include "Migalhas.h"
//ainda nao tenho as migalhas

using namespace std;

class Tela {
	//int **grelha;//defini aqui int-->at� saber basicamente o tipo que vou ter de definir aqui, pois ainda preciso de analisar
	int n_linhas;//para saber o n�de colunas associado
	int n_colunas;
	int tam;
	vector<Comunidade*> c; //vetor de comunidades
	vector<Migalhas*> m;
	int contador_iteracoes;
	static int energia_migalha;
	static int percentagem_migalhas_iniciais;
	static int migalhas_cada_instante;
	string nome;
public:
	Tela(int,string);//na construcao da tela � apenas mencionado o numero de linhas e apartir de a� � criada uma esp�cie de "lista-ligada/matriz bidimensional"
	~Tela();//destrutor
	int get_linhas() const;
	int get_colunas() const;
	void acrescenta_comunidade(int,int);//nao tenho certezas representa o local onde o ninho vai ser construido//2-->construtores para os 2 casos do comando cria?
	bool remover_comunidade(int);//remover a comunidade atrav�s do numero do ninho//-->ao remover uma comunidade removo pelo numero de serie do ninho?
	bool procura_comunidade(int);//dado o numero do seu ninho
	bool procura_comunidade(int, int);//verifica se existe ninho numa determinada posicao
	bool posicao_vazia(int,int);//verifica se uma posicao esta totalmente vazia
	bool posso_posicionar_formiga(int, int, int);//recebe a posicao linha e o coluna, e o ninho//-->uma formiga apenas pode ir para celulas vazias, ou para o SEU ninho, ou para uma celula com migalhas
	bool verifica_limites(int, int);//verifica se uma determinada posicao respeita o espaco da tela
	void acrescenta_formigas_det_comunidade(char, int, int, int);
	bool remove_formigas_det_comunidade(int, int);//remove a formiga de uma determinada comunidade, que esteja naquela posi��o
	bool procura_formiga_det_comunidade(int, int);//procura uma formiga dada a sua posicao
	int get_ninho_det_formiga_det_comunidade(int, int);//retorna o ninho de uma formiga de uma determinada comunidade, que se encontra na posicao linha, coluna
	void atualiza_elementos_tela(int);//fazer o metodo que atualiza os elementos que estao presentes na tela-->recebe o numero aleat�rio de novas migalhas a serem criadas
	string lista_por_posicao_tela(int, int);//relacionado com o comando listaposicao
	string lista_mundo();
	string lista_por_comunidade(int);//comando listaninho
	void desenha_tela();
	void acrescenta_migalha(int, int);
	void remove_migalha(int, int);//dada a sua posicao
	bool procura_migalha(int, int);//dada a sua posicao
	void acrescenta_energia_ninho_det_comunidade(int, int);//dado o seu n� de ninho e a energia a acrescentar
	void acrescenta_energia_formiga_det_comunidade(int, int, int);//dada a sua posi��o, linha e coluna e a energia a acrescentar
	static void set_energia_migalhas(int);//no inicio
	static void set_percentagem_migalhas_iniciais(int);
	static void set_migalhas_cada_instante(int);
	Formigas * retorna_formiga_det_comunidade(int, int);
	int retorna_energia_det_formiga(int, int);
	int retorna_energia_migalha(int, int);
	void move_energia_det_migalha(int,int, int);
	int get_numero_iteracoes() const;
	int get_migalhas_cada_instante() const;
	Migalhas * retorna_migalha(int,int);
	Tela(const Tela &);
	Tela & operator=(const Tela &);
	void set_nome(string n) { this->nome = n; }
	string get_nome() const { return this->nome; }
};


#endif // !TELA_H

