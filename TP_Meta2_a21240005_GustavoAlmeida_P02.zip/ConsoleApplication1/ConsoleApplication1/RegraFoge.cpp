#include "RegraFoge.h"

RegraFoge::RegraFoge() {

}

RegraFoge::~RegraFoge() {

}

bool RegraFoge::condicao_regra(Formigas *f) {
	return Regras::verifica_formiga_inimiga_raio_visao(f);
}

int RegraFoge::inimiga_mais_proxima_de_si(int posicao_f_x,int posicao_f_y,vector<int> x_inimigas, vector<int> y_inimigas) {
	/*Mediante as formigas inimigas que se encontram no seu raio de visao, verifico qual a que se encontra
	a uma distancia menor da formiga a analisar, visto que � a mais perigosa*/

	vector<double>distancia;//verifica a distancia entre a formiga e as inimigas,a posicao onde existir a menor distancia tem a formiga mais perigosa, e a qual � necessario evitar
	int posicao = 0;

	for (size_t i = 0; i < x_inimigas.size(); ++i) {
		for (size_t j = 0; j < y_inimigas.size(); ++j) {
			/*calcular distancia*/
			if (i == j) {/*POSICOES COINCIDENTES DO VETOR*/
				double x= sqrt(((x_inimigas[i] - posicao_f_x) * 2) + ((y_inimigas[j] - posicao_f_y) * 2));
				distancia.push_back(x);
				i++;
			}
		}
	}

	

	//verificar qual a menor distancia
	double menor = distancia[0];
	int pos = 0;
	for (size_t i = 0; i < distancia.size(); ++i) {
		if (distancia[i] < menor) {
			menor = distancia[i];
			pos = i;
		}
	}
	//cout << pos;
	return pos;
}

void RegraFoge::executa_regra(Formigas *f) {
	/*Para a formiga a analisar verifico qual a formiga inimiga que se encontra mais proxima de si,
	mediante a posicao onde a formiga inimiga se encontra, desloco-me para uma posi��o
	contr�ria a essa formiga inimiga*/

	/*OBTENCAO DA POSICAO DA FORMIGA E DO SEU RAIO DE VISAO*/
	int raio_visao_formiga = f->get_rv();
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*POSICOES QUE PODEM SER VISUALIZADAS PELA FORMIGA*/
	int x_max_vis = x_inicio + f->get_rv();
	int x_min_vis = x_inicio - f->get_rv();
	int y_min_vis = y_inicio - f->get_rv();
	int y_max_vis = y_inicio + f->get_rv();

	/*VETOR DE X E Y QUE GUARDA AS POSICOES DAS FORMIGAS INIMIGAS, PARA VERIFICAR QUAL � A QUE SE ENCONTRA MAIS PROXIMA DE SI*/
	vector<int> x_inimigas;
	vector<int> y_inimigas;

	/*PERCORRER AS POSICOES PARA AS QUAIS A FORMIGA PODE ACEDER, GUARDANDO NO VETOR, AS POSICOES ONDE SE ENCONTRAM AS FORMIGAS INIMIGAS*/
	for (int i = x_min_vis; i < x_max_vis; ++i) {
		for (int j = y_min_vis; j < y_max_vis; ++j) {
			if (f->encontrei_inimiga(i, j) == true) {
				x_inimigas.push_back(i);
				y_inimigas.push_back(j);
			}
		}
	}

	/*CHAMADA DA FUNCAO QUE RETORNA A POSICAO ONDE SE ENCONTRA A FORMIGA INIMIGA MAIS PROXIMA DA FORMIGA A ANALISAR*/
	int pos=this->inimiga_mais_proxima_de_si(x_inicio, y_inicio, x_inimigas, y_inimigas);

	/*VETOR QUE IRA CONTER AS POSICOES PARA ONDE IRA A FORMIGA*/
	vector<int>nova_posicao;

	/*CHAMADA DA FUNCAO QUE RETORNA A POSICAO PARA A QUAL A FORMIGA SE DEVE MOVER*/
	nova_posicao = Regras::move_direccao_oposta_formiga_inimiga(f, x_inimigas[pos], y_inimigas[pos]);//-->ver aqui isto

	/*A FORMIGA MOVE SE PARA A SUA NOVA POSICAO*/
	f->variacao_energia(nova_posicao[0], nova_posicao[1]);
	f->move_patas(nova_posicao[0],nova_posicao[1]);

}