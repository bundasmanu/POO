#pragma once
#ifndef REGRAPROCURAMIGALHA_H
#define REGRAPROCURAMIGALHA_H
#include<iostream>
#include<string>
#include "Regras.h"

class RegraProcuraMigalha : public Regras {

public:
	RegraProcuraMigalha();
	~RegraProcuraMigalha();
	int quantas_migalhas_raio_visao(Formigas *);
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraProcuraMigalha(*this); }
};

#endif // !REGRAPROCURAMIGALHA_H

