#pragma once
#ifndef REGRACOMEMIGALHA_H
#define REGRACOMEMIGALHA_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraComeMigalha : public Regras {

public:
	RegraComeMigalha();
	~RegraComeMigalha();
	bool existe_migalha_nas_adjacencias(Formigas *);
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraComeMigalha(*this); }
};


#endif // !REGRACOMEMIGALHA_H

