#pragma once
#ifndef APLICACAO_H
#define	APLICACAO_H
#include<iostream>
#include<string>
#include<sstream>
#include<fstream>
#include<vector>
#include "Comandos.h"
#include "Desenho.h"
#include "Ninho.h"

using namespace std;

class Aplicacao {
	int estado;
	Comandos *c;
	Desenho d;//construtor por omissao
public:
	Aplicacao();//construtor
	~Aplicacao();
	void pede_dados();
};

#endif // !APLICACAO_H

