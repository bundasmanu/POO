#include "RegraAjudaAmiga.h"
#include "Comunidade.h"
#include "Tela.h"

RegraAjudaAmiga::RegraAjudaAmiga() {

}

RegraAjudaAmiga::~RegraAjudaAmiga() {

}

bool RegraAjudaAmiga::existe_formiga_amiga_na_adjacencia(Formigas *f) {
	/*se existe uma formiga amiga nas suas adjacencias, retorna true,
	senao false*/

	for (int i = f->get_linha() - 1; i <= f->get_linha() + 1; ++i) {
		for (int j = f->get_coluna() - 1; j <= f->get_coluna() + 1; ++j) {
			if ((i == f->get_linha() - 1 && j == f->get_coluna()) || (i == f->get_linha() && j == f->get_coluna() - 1) || (i == f->get_linha() && j == f->get_coluna() + 1) || (i == f->get_linha() + 1 && j == f->get_coluna())) {
				if (f->encontrei_amiga(i, j) == true) {
					return true;
				}
			}
		}
	}
	return false;
}

int RegraAjudaAmiga::verifica_qual_tem_menos_energia(Formigas *f, vector<int> x_amiga, vector<int> y_amiga) {

	/*SE EXISTE APENAS UMA FORMIGA NA ADJACENCIA, RETORNA LOGO*/
	if (x_amiga.size() == 1 && y_amiga.size() == 1) {
		return 0;
	}
	
	/*VETOR QUE GUARDA A ENERGIA DAS FORMIGAS*/
	vector<int> energias;
	int pos;

	/*PERCORRER OS VETORES DAS POSICOES DAS FORMIGAS*/
	for (size_t i = 0; i < x_amiga.size(); ++i) {
		for (size_t j = 0; j < y_amiga.size(); ++j) {
			if (i == j) {
				energias.push_back(f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_energia_det_formiga(x_amiga[i], y_amiga[j]));
			}
		}
	}
	
	/*VERIFICACAO DE QUAL POSSUI MENOS ENERGIA*/
	pos = 0;
	int menor = energias[0];

	for (int i = 0; i < energias.size(); ++i) {
		if (energias[i] < menor) {
			menor = energias[i];
			pos = i;
		}
	}
	return pos;
}

bool RegraAjudaAmiga::condicao_regra(Formigas *f) {
	if (this->existe_formiga_amiga_na_adjacencia(f) == true) {
		return true;
	}
	return false;
}

void RegraAjudaAmiga::executa_regra(Formigas *f) {
	/*Mediante a adjacencia da formiga coloco num vetor as posicoes onde se encontram as formigas amigas na adjacencia,
	depois verifico qual a que tem menos energia, de seguida a energia dessa formiga aumenta 5% e a minha diminui 5%*/

	/*VETOR ONDE ESTARAO AS FORMIGAS, QUE SE ENCONTRAREM NAS ADJACENCIAS*/
	vector<int> x_amigas;
	vector<int> y_amigas;

	/*PERCORRER AS POSICOES DA ADJACENCIA DA FORMIGA*/
	for (int i = f->get_linha() - 1; i <= f->get_linha() + 1; ++i) {
		for (int j = f->get_coluna() - 1; j <= f->get_coluna() + 1; ++j) {
			if ((i == f->get_linha() - 1 && j == f->get_coluna()) || (i == f->get_linha() && j == f->get_coluna() - 1) || (i == f->get_linha() && j == f->get_coluna() + 1) || (i == f->get_linha() + 1 && j == f->get_coluna())) {
				if (f->encontrei_amiga(i, j) == true) {
					x_amigas.push_back(i);
					y_amigas.push_back(j);
				}
			}
		}
	}

	/*RETORNO DA POSICAO NO VETOR, DA FORMIGA COM MENOS ENERGIA*/
	int posicao = this->verifica_qual_tem_menos_energia(f, x_amigas, y_amigas);

	/*A FORMIGA AMIGA AUMENTA EM 5% A SUA ENERGIA*/
	Formigas *amiga = f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_formiga_det_comunidade(x_amigas[posicao], y_amigas[posicao]);
	amiga->move_energia(amiga->get_energia() + (f->get_energia()*0.05));

	/*A FOMIGA REDUZ A SUA ENERGIA EM 5%*/
	f->move_energia(f->get_energia() - (f->get_energia()*0.05));

}