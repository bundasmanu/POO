#pragma once
#ifndef REGRAFOGE_H
#define REGRAFOGE_H
#include<iostream>
#include<string>
#include "Regras.h"	

using namespace std;

class RegraFoge : public Regras {

public:
	RegraFoge();
	~RegraFoge();
	virtual bool condicao_regra(Formigas *);//representa a condi��o que define se uma regra deve ou n�o ser executada
	virtual void executa_regra(Formigas *);//execu��o da regra
	int inimiga_mais_proxima_de_si(int, int, vector<int>, vector<int>);//recebe os vetores com as inimigas, retorna a posicao onde se encontra a inimiga mais proxima
	Regras * clone() { return new RegraFoge(*this); }
};

#endif // !REGRAFOGE_H

