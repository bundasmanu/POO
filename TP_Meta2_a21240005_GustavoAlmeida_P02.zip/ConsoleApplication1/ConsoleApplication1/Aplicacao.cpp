#include "Aplicacao.h"
//stoi-->converte string em inteiro

Aplicacao::Aplicacao() {
	estado = 1;//encontra-se ativa
	this->c = new Comandos();
}

Aplicacao::~Aplicacao() {
	delete c;
}

void Aplicacao::pede_dados() {
	string entrada;//linha digitada
	stringstream ss;//separacao das strings em "comandos adequados"
	vector<string> s;//guarda os comandos digitados
	int verificacao_j�_tou_na_simulacao = 0;
	int mundo_atraves_comando = 0;
	int contador2 = 0;//se o utilizador escrever os comandos de configura��o � m�o
	while (entrada.compare("sair") != 0) {

		/*MENU DE BOAS VINDAS*/
		d.Desenho_abertura_inicio();

		/*COLOCACAO DO CURSOR*/
		d.Desenho_inicio_configuracao(12);

		/*LEITURA DOS DADOS*/

		getline(cin, entrada);

		ss << entrada;

		/*Coloco cada palavra lida num vetor de strings*/
		do {
			string ficticia;
			ss >> ficticia;
			s.push_back(ficticia);
		} while (ss);

		if (s[0] == "executa" && !s[1].empty()) {//se a 1 palavra for executa
			cout << "\nA executar...\n";
			c->executa(s[1]);
		}
		if (s[0] == "inicio" && verificacao_j�_tou_na_simulacao==0) {//apenas posso executar este comando 1 vez
			if (this->c->get_contador() +contador2>=6) {//j� foram definidos os parametros que preciso no inicio//-->neste caso ainda s� fiz para o primeiro
				cout << "\nFoi dado inicio a fase de simulacao\n";
				verificacao_j�_tou_na_simulacao = 1;
				/*CRIO LOGO O NUMERO DE MIGALHAS PREDEFINIDAS*/
				for (int i = 0; i < this->c->get_n(); ++i) {
					int k[2];
					this->c->gera_numeros_aleatorio(k);//gero numeros aleatorios*/
					this->c->migalha(k[0], k[1]);//depois crio a migalha
				}
				/*FACO UMA COPIA DO MUNDO DEFAULT*/
				c->grava_ficheiro("default");//mundo default
			}
			else {
				cout << "Primeiro necessita de definir os parametros de configuracao\n";
			}
		}
		if (s[0] == "defen" && this->c->apenas_digitos(s[1]) == true) {
			this->c->defen(stoi(s[1]));
			contador2++;//comando obrigatorio
		}
		if (s[0] == "defmundo" && this->c->apenas_digitos(s[1]) == true && mundo_atraves_comando==0) {
			this->c->defmundo(stoi(s[1]));
			contador2++;//comando obrigatorio
			mundo_atraves_comando = 1;//aceitar apenas uma vez o comando de cria��o do mundo
		}
		if (s[0] == "defpc" && this->c->apenas_digitos(s[1]) == true && !s[1].empty()) {
			this->c->defpc(stoi(s[1]));
			contador2++;//comando obrigatorio
		}
		if (s[0] == "defvt" && this->c->apenas_digitos(s[1]) == true && !s[1].empty()) {
			this->c->defvt(stoi(s[1]));
		}
		if (s[0] == "defmi" && this->c->apenas_digitos(s[1]) == true && !s[1].empty()) {
			this->c->defmi(stoi(s[1]));
			contador2++;//comando obrigatorio
		}
		if (s[0] == "defme" && this->c->apenas_digitos(s[1]) == true && !s[1].empty()) {
			this->c->defme(stoi(s[1]));
			contador2++;//comando obrigatorio
		}
		if (s[0] == "defnm" && this->c->apenas_digitos(s[1]) == true && !s[1].empty()) {
			this->c->defnm(stoi(s[1]));
			contador2++;//comando obrigatorio
		}
		if (s[0].compare("foca") == 0 && !s[1].empty() && !s[2].empty() && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true) {
			if (verificacao_j�_tou_na_simulacao == 1) {
				d.Desenho_apaga_ecra();
				d.Desenho_abertura_inicio();
				this->c->desenha();
				d.Desenho_foca_mundo(stoi(s[1]), stoi(s[2]));
			}
			else {
				cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
			}
		}
		else if (s[0].compare("foca") == 0 && (s[1].empty() || s[2].empty() || this->c->apenas_digitos(s[1]) == false || this->c->apenas_digitos(s[2]) == false)) {
			cout << "Nao digitou todos os parametros.\n";
		}
		if (s[0].compare("guarda") == 0 && !s[1].empty()) {
			if (verificacao_j�_tou_na_simulacao == 1) {
				bool n=c->grava_ficheiro(s[1]);
				if (n == true) {
					cout << "\nGravacao concluida\n";
				}
			}
			else {
				cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
			}
		}
		else if (s[0].compare("guarda") == 0 && s[1].empty()) {
			cout << "Nao digitou todos os parametros.\n";
		}
		if (s[0].compare("muda") == 0 && !s[1].empty()) {
			if (verificacao_j�_tou_na_simulacao == 1) {
				bool n=c->muda_ficheiro(s[1]);
				if (n == true) {
					cout << "\nMudanca para uma copia efetuada com sucesso\n";
				}
			}
			else {
				cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
			}
		}
		else if (s[0].compare("muda") == 0 && s[1].empty()) {
			cout << "Nao digitou todos os parametros.\n";
		}
		if (s[0].compare("apaga") == 0 && !s[1].empty()) {
			if (verificacao_j�_tou_na_simulacao == 1) {
				bool n=c->apaga_ficheiro(s[1]);
				if (n == true) {
					cout << "\nApagada uma copia\n";
				}
				if (n == true && s[1].compare("default") == 0) {
					verificacao_j�_tou_na_simulacao = 0;
					mundo_atraves_comando = 0;
					contador2 = 0;
				}
			}
			else {
				cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
			}
		}
		else if (s[0].compare("apaga") == 0 && s[1].empty()) {
			cout << "Nao digitou todos os parametros.\n";
		}

		/*COMANDOS ONDE � NECESSARIO MOSTRAR DE SEGUIDA O MUNDO*/
		if (verificacao_j�_tou_na_simulacao == 1  && s[0]!="defmundo" && (s[0]=="tempo" || s[0]=="ninho" || s[0]=="criaf" || s[0] == "listamundo" || s[0] == "listaninho" || s[0] == "listaposicao" || s[0]=="migalha" || s[0]=="cria1" || s[0]=="energninho" || s[0]=="energformiga" || s[0]=="mata" || s[0]=="inseticida")) {
			if (s[0] == "ninho" && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true && !s[2].empty()) {//falta fazer as verificacoes
				if (verificacao_j�_tou_na_simulacao == 1) {
					c->cria_ninho(stoi(s[1]), stoi(s[2]));
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			if (s[0] == "criaf" && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[3]) == true && !s[1].empty() && !s[2].empty() && !s[3].empty()) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					char c = toupper(s[2][0]);//caso escreva em minuscula
					//cout << c << endl;
					for (int i = 0; i < stoi(s[1]); ++i) {
						int n[2];
						this->c->gera_numeros_aleatorios_formigas(&*n);
						//cout << n[0] << " " << n[1] << endl;
						this->c->cria_f(c, stoi(s[3]), n[0], n[1]);
						//cout << "\nentrada\n";
					}
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "criaf" && (this->c->apenas_digitos(s[1]) != true || this->c->apenas_digitos(s[3]) != true || s[1].empty() || s[2].empty() || s[3].empty())) {
				cout << "Nao digitou todos os parametros.\n";
			}
			if (s[0] == "listamundo") {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->lista_mundo();
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			if (s[0] == "listaninho" && this->c->apenas_digitos(s[1]) == true && !s[1].empty()) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->lista_ninho(stoi(s[1]));
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "listaninho" && (this->c->apenas_digitos(s[1]) != true || s[1].empty())) {
				cout << "Nao indicou os parametros corretos.\n";
			}
			if (s[0] == "listaposicao" && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true && !s[1].empty() && !s[2].empty()) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->lista_por_posicao(stoi(s[1]), stoi(s[2]));
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "listaposicao" && (this->c->apenas_digitos(s[1]) != true || this->c->apenas_digitos(s[2]) != true || s[1].empty() || s[2].empty())) {
				cout << "Nao indicou os parametros corretos.\n";
			}
			if (s[0] == "migalha" && !s[1].empty() && !s[2].empty() && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					//cout << stoi(s[1]) << " e " << stoi(s[2]);
					this->c->migalha(stoi(s[1]), stoi(s[2]));
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "migalha" && (s[1].empty() || s[2].empty() || this->c->apenas_digitos(s[1]) == true || this->c->apenas_digitos(s[2]) == true)) {
				cout << "Nao indicou os parametros corretos.\n";
			}
			if (s[0] == "tempo" && s[1].empty()) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->tempo();
				}
			}
			if (s[0] == "tempo" && !s[1].empty() && this->c->apenas_digitos(s[1]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					for (int i = 0; i < stoi(s[1]); ++i) {
						this->c->tempo();
					}
				}
			}
			if (s[0] == "cria1" && !s[2].empty() && !s[3].empty() && !s[4].empty() && this->c->apenas_digitos(s[2])==true && this->c->apenas_digitos(s[3]) == true && this->c->apenas_digitos(s[4]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					char cc = toupper(s[1][0]);
					//cout << cc << stoi(s[2]) << stoi(s[3]) << stoi(s[4]) << endl;
					this->c->cria_1(cc, stoi(s[2]), stoi(s[3]), stoi(s[4]));
				}
				else {
					cout << "Ainda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "cria1" && (s[2].empty() || s[3].empty() || s[4].empty() || this->c->apenas_digitos(s[2]) != true || this->c->apenas_digitos(s[3]) != true || this->c->apenas_digitos(s[4]) != true)) {
				cout << "Nao digitou todos os parametros.\n";
			}
			if (s[0] == "energninho" && !s[1].empty() && !s[2].empty() && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->energninho(stoi(s[1]), stoi(s[2]));
				}
				else {
					cout<<"\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0]=="energninho" && (s[1].empty() || s[2].empty() || this->c->apenas_digitos(s[1])!=true || this->c->apenas_digitos(s[2])!=true)) {
				cout << "Nao digitou todos os parametros.\n";
			}
			if (s[0] == "energformiga" && !s[1].empty() && !s[2].empty() && !s[3].empty() && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true && this->c->apenas_digitos(s[3]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->energformiga(stoi(s[1]), stoi(s[2]), stoi(s[3]));
				}
				else {
					cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0].compare("energformiga")==0 && (s[1].empty() || s[2].empty() || s[3].empty() || this->c->apenas_digitos(s[1]) != true || this->c->apenas_digitos(s[2]) != true || this->c->apenas_digitos(s[3]) != true)) {
				cout << "Nao digitou todos os parametros.\n";
			}
			if (s[0] == "mata" && !s[1].empty() && !s[2].empty() && this->c->apenas_digitos(s[1]) == true && this->c->apenas_digitos(s[2]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->mata(stoi(s[1]), stoi(s[2]));
				}
				else {
					cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "mata" && (s[1].empty() || s[2].empty() || this->c->apenas_digitos(s[1]) != true || this->c->apenas_digitos(s[2]) != true)) {
				cout << "Nao digitou todos os parametros.\n";
			}
			if (s[0].compare("inseticida") == 0 && !s[1].empty() && this->c->apenas_digitos(s[1]) == true) {
				if (verificacao_j�_tou_na_simulacao == 1) {
					this->c->inseticida(stoi(s[1]));
				}
				else {
					cout << "\nAinda nao pode inserir estes comandos, nao se encontra na fase de simulacao.\n";
				}
			}
			else if (s[0] == "inseticida" && (s[1].empty() || this->c->apenas_digitos(s[1]) != true)) {
				cout << "Nao digitou todos os parametros.\n";
			}

			/*if("o utilizador digitou este comando"){
				entao chamo o metodo aliado a este comando que se encontra na classe Gestor
			}*/

			/*A ESPERA DE ENTER PARA MOSTRAR O MUNDO*/
			d.Desenho_nova_iteracao();

			/*DEPOIS DE O UTILIZADOR LER O COMANDO E PRESSIONAR ENTER, MOSTRO O MUNDO*/
			d.Desenho_apaga_ecra();
			d.Desenho_abertura_inicio();
			this->c->desenha();
			d.Desenha_mundo(this->c->get_tamanho_tela());
		}

		/*TEXTO PADRAO-->COR BRANCA*/
		d.Desenho_texto_padrao();

		/*A ESPERA DO ENTER//-->para avancar*/
		if (s[0]!="executa") {
			d.Desenho_nova_iteracao();//digite nova tecla
		}

		/*APAGO O ECRA*/
		d.Desenho_apaga_ecra();

		s.clear();//apago o que tenho no vetor visto que j� n�o preciso nada dele
		ss.clear();//reset � stringstream para que esta volte a ser utilizada
	}
}

