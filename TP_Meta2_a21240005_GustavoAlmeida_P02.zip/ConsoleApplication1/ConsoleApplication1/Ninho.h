#pragma once
#ifndef NINHO_H
#define NINHO_H
#include<iostream>
#include<string>
#include<sstream>
#include<vector>
#include<time.h>
#include "Consola.h"

using namespace std;

class Comunidade;

class Ninho {
	int energia;
	static int n_serie;
	int *n_serie_oficial;
	int linha;
	int coluna;
	int energia_inicial;
	Comunidade *cc;
public:
	Ninho(int,int,int);
	~Ninho();
	int get_linha() const;
	int get_coluna() const;
	int get_energia() const;
	void set_energia(int);
	int get_nserie() const;
	void set_comunidade(Comunidade *);
	int verifica_energia();
	string lista_ninho();
	void desenha_ninho(int);
	void move_energia(int);
	void cria_nova_formiga();
	Ninho(const Ninho &);
	Ninho & operator=(const Ninho &);
};

#endif // !NINHO_H

