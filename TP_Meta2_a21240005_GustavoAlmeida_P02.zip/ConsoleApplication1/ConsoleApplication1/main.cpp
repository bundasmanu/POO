#include "Aplicacao.h"

void main() {
	Aplicacao *app = new Aplicacao();
	app->pede_dados();
	delete app;
}