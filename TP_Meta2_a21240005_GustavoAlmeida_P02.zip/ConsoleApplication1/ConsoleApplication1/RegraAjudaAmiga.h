#pragma once
#ifndef REGRAAJUDAAMIGA_H
#define REGRAAJUDAAMIGA_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraAjudaAmiga : public Regras{

public:
	RegraAjudaAmiga();
	~RegraAjudaAmiga();
	bool existe_formiga_amiga_na_adjacencia(Formigas *);
	int verifica_qual_tem_menos_energia(Formigas *, vector<int>, vector<int>);//retorna a posicao onde se encontra a formiga no vetor
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraAjudaAmiga(*this); }
};

#endif // !REGRAAJUDAAMIGA_H
