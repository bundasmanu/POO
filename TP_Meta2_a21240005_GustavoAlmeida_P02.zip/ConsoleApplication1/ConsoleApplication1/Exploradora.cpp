#include "Exploradora.h"
//adicionado as regras
#include "Regras.h"
#include "RegraComeMigalha.h"
#include "RegraPasseia.h"

Exploradora::Exploradora(int l,int c): Formigas(200,10,8,l,c,0),letra('E') {
	this->meu_n_serie = new int(Formigas::get_nserie());
	Formigas::acrescenta_regras(new RegraComeMigalha());
	Formigas::acrescenta_regras(new RegraPasseia());
}

string Exploradora::Obtem_info() {
	ostringstream frase;
	frase << "Formiga\n Numero de Serie: "<<this->get_nserie()<<" Tipo Formiga: "<< this->letra << endl;
	frase << Formigas::Obtem_info();
	return frase.str();
}

char Exploradora::Obtem_car() {
	return this->letra;
}

int Exploradora::get_rm() const{
	return Formigas::get_rm();
}

int Exploradora::get_rv() const {
	return Formigas::get_rv();
}

double Exploradora::get_energia_retira_migalha() const {
	return Formigas::get_energia_retira_migalha();
}

int Exploradora::get_nserie() const {
	return *meu_n_serie;
}

void Exploradora::desenha_formiga(int cor) {
	Formigas::desenha_formiga(cor);
}

void Exploradora::Comportamento() {
	Formigas::Comportamento();
}

void Exploradora::variacao_energia(int ll, int cc) {
	int e = Formigas::get_energia();
	int x = Formigas::get_linha();
	int y = Formigas::get_coluna();
	int abs1 = abs(x - ll);
	int abs2 = abs(y - cc);
	int energia_remover = 1 + abs1 + abs2;
	//cout << "\n" << energia_remover << endl;
	this->set_energia(Formigas::get_energia() - energia_remover);
}

Exploradora::Exploradora(const Exploradora &e) : Formigas(e) {
	this->letra = e.letra;
	this->meu_n_serie = new int(e.get_nserie());
	//Formigas::acrescenta_regras(new RegraComeMigalha());
	//Formigas::acrescenta_regras(new RegraPasseia());
}

Exploradora & Exploradora::operator=(const Exploradora &e) {
	delete this->meu_n_serie;

	/*redefinicao dos atributos*/
	Formigas::operator=(e);//chamada ao operador de atribuicao da Formiga
	this->letra = e.letra;
	this->meu_n_serie = new int(e.get_nserie());
	return (*this);
}