#include "Surpresa.h"
#include "RegraSacrificar.h"
#include "RegraDestroiComida.h"
#include "RegraAjudaAmiga.h"
#include "RegraPasseia.h"

Surpresa::Surpresa(int l, int c) : Formigas(100, 6, 4, l, c, 0), letra('S') {//come uma migalha toda
	this->meu_n_serie = new int(Formigas::get_nserie());
	Formigas::acrescenta_regras(new Regrassacrificar());
	Formigas::acrescenta_regras(new RegraAjudaAmiga());
	Formigas::acrescenta_regras(new RegraDestroiComida());
	Formigas::acrescenta_regras(new RegraPasseia());
}

string Surpresa::Obtem_info() {
	ostringstream frase;
	frase << "Formiga\n Numero de Serie: " << this->get_nserie() << " Tipo Formiga: " << this->letra << endl;
	frase << Formigas::Obtem_info();
	return frase.str();
}

char Surpresa::Obtem_car() {
	return this->letra;
}

int Surpresa::get_rm() const {
	return Formigas::get_rm();
}

int Surpresa::get_rv() const {
	return Formigas::get_rv();
}

double Surpresa::get_energia_retira_migalha() const {
	return Formigas::get_energia_retira_migalha();
}

int Surpresa::get_nserie() const{
	return *meu_n_serie;
}

void Surpresa::desenha_formiga(int cor) {
	Formigas::desenha_formiga(cor);
}

void Surpresa::Comportamento() {
	Formigas::Comportamento();
}

void Surpresa::variacao_energia(int ll, int cc) {
	int e = Formigas::get_energia();
	int x = Formigas::get_linha();
	int y = Formigas::get_coluna();
	int abs1 = abs(x - ll);
	int abs2 = abs(y - cc);
	int energia_remover = 1 + abs1 + abs2;
	//cout << "\n" << energia_remover << endl;
	this->set_energia(Formigas::get_energia() - energia_remover);
}

Surpresa::Surpresa(const Surpresa &s) : Formigas(s){
	this->letra = s.letra;
	this->meu_n_serie = new int(s.get_nserie());
}

Surpresa & Surpresa::operator=(const Surpresa &s) {
	delete this->meu_n_serie;

	/*redefinicao dos atributos*/
	Formigas::operator=(s);//chamada ao operador de atribuicao da Formiga
	this->letra = s.letra;
	this->meu_n_serie = new int(s.get_nserie());
	return (*this);
}