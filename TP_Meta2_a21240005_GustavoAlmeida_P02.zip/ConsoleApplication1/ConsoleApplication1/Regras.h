#pragma once
#ifndef REGRAS_H
#define REGRAS_H
#include<iostream>
#include<string>
#include<sstream>
#include<random>
#include <cstdlib>
#include<vector>
#include<algorithm>
#include<time.h>
/*#include "Comunidade.h"
#include "Ninho.h"*/
#include "Formigas.h"

using namespace std;

class Tela;

class Regras {
	Tela *te;//para aplicar as regras, � necessario saber varios aspectos do mundo
public:
	Regras();//construtor sem nada
	~Regras();//destrutor sem nada
	bool verifica_formiga_inimiga_raio_visao(Formigas *);
	int qual_formiga_tem_mais_energia(Formigas *, vector<int>, vector<int>);//retorna a posicao onde se encontra a formiga inimiga com mais energia
	int qual_migalha_tem_mais_energia(Formigas *, vector<int>, vector<int>);
	vector<int>aproximacao_formiga_inimiga_ou_migalha(Formigas *, int, int);//retorna num vetor a nova posicao da Formiga, e recebe a formiga a analisar e a posicao x e y onde se encontra a formiga inimiga com mais energia
	vector<int> move_direccao_oposta_formiga_inimiga(Formigas *, int, int);//recebe a Formiga a analisar e a posicao linha e coluna da formiga inimiga, retornando a posicao para a qual deve ir
	void set_tela(Tela *);
	virtual bool condicao_regra(Formigas *)=0;
	virtual void executa_regra(Formigas*)=0;
	virtual Regras * clone() = 0;
};


#endif // !REGRAS_H

