#include "RegraComeMigalha.h"
#include "Comunidade.h"
#include "Tela.h"

RegraComeMigalha::RegraComeMigalha() {

}

RegraComeMigalha::~RegraComeMigalha() {

}

bool RegraComeMigalha::existe_migalha_nas_adjacencias(Formigas *f) {
	/*Verifica se na sua posicao ou a esquerda,direita,baixo e cima tem uma migalha*/

	/*POSICAO X E Y DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*VERIFICACAO SE NAS SUAS ADJACENCIAS EXISTE PELOS MENOS UMA MIGALHA*/
	if (f->encontrei_migalha(x_inicio, y_inicio) == true || f->encontrei_migalha(x_inicio - 1, y_inicio) == true || f->encontrei_migalha(x_inicio + 1, y_inicio) == true || f->encontrei_migalha(x_inicio, y_inicio + 1) == true || f->encontrei_migalha(x_inicio, y_inicio - 1) == true) {
		return true;
	}
	return false;
}

bool RegraComeMigalha::condicao_regra(Formigas *f) {
	if (this->existe_migalha_nas_adjacencias(f) == true) {
		return true;
	}
	return false;
}

void RegraComeMigalha::executa_regra(Formigas *f) {

	/*POSICAO X E Y DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*VETOR QUE IRA ARMAZENAR AS POSICOES DAS MIGALHAS ENCONTRADAS NAS ADJACENCIAS DAS FORMIGAS*/
	vector<int> x_migalhas;
	vector<int> y_migalhas;

	/*VERIFICACAO SE EXISTE MIGALHA NA ADJACENCIA E COLOCACAO NO VETOR*/
	for (int i = f->get_linha() - 1; i <= f->get_linha() + 1; ++i) {
		for (int j = f->get_coluna() - 1; j <= f->get_coluna() + 1; ++j) {
			if ((i==f->get_linha()-1 && j==f->get_coluna()) || (i==f->get_linha() && j==f->get_coluna()-1) || (i==f->get_linha() && j==f->get_coluna())|| (i==f->get_linha() && j==f->get_coluna()+1)||(i==f->get_linha()+1 && j==f->get_coluna())) {
				if (f->encontrei_migalha(i, j) == true) {
					x_migalhas.push_back(i);
					y_migalhas.push_back(j);
				}
			}
		}
	}

	//cout << "\ntrack1\n";

	/*RETORNA A POSICAO DA MIGALHA QUE CONTEM MAIS ENERGIA*/
	int posicao_migalha_mais_energia = Regras::qual_migalha_tem_mais_energia(f, x_migalhas, y_migalhas);

	//cout << "\ntrack2\n";

	/*POSICAO X E Y DA MIGALHA COM MAIS ENERGIA*/
	int pos_mig_x = x_migalhas[posicao_migalha_mais_energia];
	int pos_mig_y = y_migalhas[posicao_migalha_mais_energia];

	//cout << "\ntrack3\n";

	/*MIGALHA REDUZ A SUA ENERGIA, MEDIANTE A ENERGIA QUE O TIPO DE FORMIGA RETIRA*/
	int energia_atual_da_migalha = f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_energia_migalha(pos_mig_x, pos_mig_y);
	double energia_retirar=f->get_energia_retira_migalha();
	//cout << energia_retirar << endl;
	//cout << "\ntrack4\n";

	/*RETIRAR ENERGIA A MIGALHA*/
	f->retorna_minha_comunidade()->retorna_tela_comunidade()->move_energia_det_migalha(energia_atual_da_migalha*energia_retirar, pos_mig_x, pos_mig_y);

	//cout << "\ntrack5\n";

	/*FORMIGA AUMENTA A SUA ENERGIA*/
	f->move_energia(f->get_energia() + (energia_atual_da_migalha*(1-energia_retirar)));

	//cout << "\ntrack6\n";
}