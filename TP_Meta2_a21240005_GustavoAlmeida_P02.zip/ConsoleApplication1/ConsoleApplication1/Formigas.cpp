#include "Formigas.h"
#include "Ninho.h"
#include "Comunidade.h"
#include "Regras.h"
#include "RegraFoge.h"
#include "Tela.h"//inclusao do header file da Tela

Formigas::Formigas(int e,int r_v,int r_m,int l,int c,double energia_r): r_visao(r_v),r_mov(r_m),energia_retira_migalha(energia_r){
	//gerar numero aleatorio para a linha e a coluna//-->necessito de saber o tamanho da tela
	//as formigas sao criadas na posicao do ninho
	this->energia = e;
	this->n_serie = this->n_serie + 1;
	this->energia_inicial = e;
	this->linha = l;
	this->coluna = c;
	this->entrei_ninho = 0;
}

Formigas::~Formigas() {
	for (size_t i = 0; i < this->regrass.size(); ++i) {
		delete regrass[i];
	}
	regrass.clear();
}

int Formigas::get_linha() const{
	return this->linha;
}

int Formigas::get_coluna() const{
	return this->coluna;
}

void Formigas::set_linha(int n) {
	this->linha = n;
}

void Formigas::set_coluna(int n) {
	this->coluna = n;
}

int Formigas::get_energia_inicial() const {
	return this->energia_inicial;
}

string Formigas::Obtem_info() {
	ostringstream frase;
	frase << " Linha: " << this->get_linha() << " Coluna: " << this->get_coluna()<< " Energia: "<<this->energia <<"\n";
	return frase.str();
}

int Formigas::get_energia() const {
	return this->energia;
}

void Formigas::set_energia(int n) {
	this->energia = n;
}

void Formigas::move_energia(int n) {
	this->set_energia(n);
}

void Formigas::move_patas(int l, int c) {
	this->set_linha(l);
	this->set_coluna(c);
}

bool Formigas::verifica_energia() {
	if (this->get_energia() <= 0) {
		//cout << "\nrr\n";
		this->c->remove_formiga(this->get_linha(), this->get_coluna());
		//cout << "\ntt\n";
		return false;
	}
	return true;
}

//pergunto ao ninho onde estou, qual o seu numero de serie
int Formigas::get_ninho() const {
	return this->ni->get_nserie();
}

int Formigas::get_entrei_ninho() const {
	return this->entrei_ninho;
}

void Formigas::set_ninho(Ninho *ninho) {
	this->ni = ninho;
}

void Formigas::set_comunidade(Comunidade *co) {
	this->c = co;
}

char Formigas::Obtem_car() {//tentar arranjar melhor maneira
	char x = ' ';
	return x;
}

bool Formigas::estou_no_ninho() {
	if (this->get_linha() == this->ni->get_linha() && this->get_coluna() == this->ni->get_coluna()) {
		return true;
	}
	else {
		return false;
	}
}

//o set das formigas nao esta bem-->tenho de emendar
void Formigas::atuar_quando_estou_no_ninho() {
	//int n = this->get_energia() - this->get_energia_inicial();
		if (this->get_energia_inicial() < this->get_energia()) {//se tenho mais energia do que tinha no inicio
			this->set_energia(this->get_energia()-this->c->get_percentagem_defvt());//este valor necessita de ser ajustado
			this->ni->move_energia(this->ni->get_energia()+this->c->get_percentagem_defvt());
		}
		if (this->get_energia()<(energia_inicial*0.5) && this->get_energia_inicial() > this->get_energia()) {//n<(50% da energia inicial), tem menos de 50% da energia inicial
			this->set_energia(this->get_energia()+this->c->get_percentagem_defvt());//valor necessita de ser ajustado
			this->ni->move_energia(this->ni->get_energia() - this->c->get_percentagem_defvt());
		}
		
		//quando entra no ninho coloca a variavel entrei_ninho, com o valor da variavel que controla o numero de iteracoes, para dps s� passadas 10 iteacoes puder voltar a entrar no ninho
		this->entrei_ninho = this->retorna_minha_comunidade()->retorna_tela_comunidade()->get_numero_iteracoes();
}

int Formigas::get_rm() const {
	return this->r_mov;
}

int Formigas::get_rv() const{
	return this->r_visao;
}

double Formigas::get_energia_retira_migalha() const {
	return this->energia_retira_migalha;
}

void Formigas::desenha_formiga(int cor) {
	Consola::gotoxy(this->get_coluna(), this->get_linha());//tem de ser x->corresponde � coluna e y-> � linha, logo (coluna,linha)
	int n = this->get_energia_inicial() / 2;
	if (n < this->get_energia()) {//mais de 50% da energia inicial
		Consola::setTextColor(cor);
		Consola::setTextSize(15, 15);
		cout << (char)toupper(this->Obtem_car());
	}
	else {//menos de 50% da energia inicial
		Consola::setTextColor(cor);
		Consola::setTextSize(15, 15);
		cout << (char)tolower(this->Obtem_car());
	}
}

bool Formigas::posso_andar(int l,int c) {
	Tela *temp = this->c->retorna_tela_comunidade();
	if (temp->verifica_limites(l,c)==true) {//se a posicao para onde vai andar respeita os limites
		if (temp->posso_posicionar_formiga(l, c, this->get_ninho()) == true) {//se vai para uma posicao permitida, sem outra formiga l� dentro, ou para o ninho de outra comunidade, etc 
			return true;
		}
	}
	return false;
}

bool Formigas::encontrei_inimiga(int l, int c) {
	Tela *temp = this->c->retorna_tela_comunidade();
	if (temp->procura_formiga_det_comunidade(l, c) == true) {//se encontrei formiga naquela posicao
		if (temp->get_ninho_det_formiga_det_comunidade(l, c) != this->get_ninho()) {//verificar se a formiga pertence a uma comunidade diferente, da comunidade da formiga a ser analisada
			return true;
		}
	}
	return false;
}

bool Formigas::encontrei_amiga(int l, int c) {
	Tela *temp = this->c->retorna_tela_comunidade();
	if (temp->procura_formiga_det_comunidade(l, c) == true) {//se encontrei formiga naquela posicao
		if (temp->get_ninho_det_formiga_det_comunidade(l, c) == this->get_ninho()) {//verificar se a formiga pertence a uma comunidade diferente, da comunidade da formiga a ser analisada
			return true;
		}
	}
	return false;
}

bool Formigas::encontrei_migalha(int l, int c) {
	Tela *temp = this->retorna_minha_comunidade()->retorna_tela_comunidade();
	if (temp->procura_migalha(l, c) == true) {
		return true;
	}
	return false;
}

void Formigas::Comportamento() {
	vector<Regras*>::iterator i = this->regrass.begin();
	while (i != this->regrass.end()) {
		if ((*i)->condicao_regra(this) == true) {
			(*i)->executa_regra(this);
			return;
		}
		++i;
	}
}

void Formigas::variacao_energia(int ll, int cc) {

}

Comunidade * Formigas::retorna_minha_comunidade() {
	return this->c;
}

int Formigas::pergunta_ninho_linha() const {
	return this->ni->get_linha();
}

int Formigas::pergunta_ninho_coluna() const {
	return this->ni->get_coluna();
}

void Formigas::acrescenta_regras(Regras *r) {
	this->regrass.push_back(r);
}

Formigas::Formigas(const Formigas &f) :  energia_retira_migalha(f.energia_retira_migalha), r_mov(f.r_mov), r_visao(f.r_visao){
	this->coluna = f.coluna;
	this->linha = f.linha;
	this->energia_inicial = f.energia_inicial;
	this->energia= f.energia;
	//this->ni = new Ninho(f.ni->get_linha(),f.ni->get_coluna(),f.ni->get_energia());
	//this->c = new Comunidade(f.c->get_linha_ninho(),f.c->get_coluna_ninho());
	for (size_t i = 0; i < f.regrass.size(); ++i) {
		this->regrass.push_back(f.regrass[i]->clone());
	}
}

Formigas & Formigas::operator=(const Formigas &f) {
	delete this->ni;
	delete this->c;
	for (size_t i = 0; i < this->regrass.size(); ++i) {
		delete this->regrass[i];
	}
	this->regrass.clear();

	/*redefinicao dos novos atributos*/
	this->coluna = f.coluna;
	this->linha = f.linha;
	this->energia_inicial = f.energia_inicial;
	this->energia = f.energia;
	//this->ni = new Ninho(f.ni->get_linha(), f.ni->get_coluna(), f.ni->get_energia());
	//this->c = new Comunidade(f.c->get_linha_ninho(), f.c->get_coluna_ninho());
	for (size_t i = 0; i < f.regrass.size(); ++i) {
		this->regrass.push_back(f.regrass[i]->clone());
	}
	return (*this);
}

int Formigas::n_serie = 0;