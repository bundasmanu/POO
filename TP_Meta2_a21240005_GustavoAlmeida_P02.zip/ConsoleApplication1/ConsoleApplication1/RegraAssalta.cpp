#include "RegraAssalta.h"
#include "Comunidade.h"
#include "Tela.h"

RegraAssalta::RegraAssalta() {

}

RegraAssalta::~RegraAssalta() {

}

bool RegraAssalta::Formigas_inimigas_raio_movimento(Formigas *f) {
	/*DEFINICAO DA POSICAO INICIAL DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*DEFINICAO LIMITES DO QUADRADO DO RAIO DE MOVIMENTO DA FORMIGA*/
	int x_limite_min = f->get_linha() - f->get_rm();
	int x_limite_max = f->get_linha() + f->get_rm();
	int y_limite_min = f->get_coluna() - f->get_rm();
	int y_limite_max = f->get_coluna() + f->get_rm();

	/*VERIFICAR PARA CADA POSICAO DO QUADRADO DE MOVIMENTACAO DA FORMIGA, SE EXISTEM FORMIGAS INIMIGAS*/
	for (int i = x_limite_min; i < x_limite_max; ++i) {
		for (int j = y_limite_min; j < y_limite_max; ++j) {
			if (f->encontrei_inimiga(i, j) == true && (i!=f->get_linha() || j!=f->get_coluna())) {
				return true;
			}
		}
	}
	return false;
}

bool RegraAssalta::condicao_regra(Formigas *f) {
	bool n=this->Formigas_inimigas_raio_movimento(f);
	return n;
}

void RegraAssalta::executa_regra(Formigas *f) {
	/*OBTENCAO DA POSICAO DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*POSICOES QUE PODEM SER MOVIMENTADAS PELA FORMIGA*/
	int x_max_vis = x_inicio + f->get_rm();
	int x_min_vis = x_inicio - f->get_rm();
	int y_min_vis = y_inicio - f->get_rm();
	int y_max_vis = y_inicio + f->get_rm();

	/*VETOR DE X E Y QUE GUARDA AS POSICOES DAS FORMIGAS INIMIGAS*/
	vector<int> x_inimigas;
	vector<int> y_inimigas;

	/*PERCORRER AS POSICOES PARA AS QUAIS A FORMIGA PODE ACEDER, GUARDANDO NO VETOR, AS POSICOES ONDE SE ENCONTRAM AS FORMIGAS INIMIGAS*/
	for (int i = x_min_vis; i < x_max_vis; ++i) {
		for (int j = y_min_vis; j < y_max_vis; ++j) {
			if (f->encontrei_inimiga(i, j) == true) {
				x_inimigas.push_back(i);
				y_inimigas.push_back(j);
			}
		}
	}

	/*MEDIANTE AS FORMIGAS INIMIGAS EXISTENTES NO RAIO DE MOVIMENTO DA FORMIGA, VERIFICACAO DE QUAL POSSUI MAIS ENERGIA*/
	int posicao_vetor_formiga_mais_energia = Regras::qual_formiga_tem_mais_energia(f, x_inimigas, y_inimigas);

	/*OBTENCAO DA POSICAO LINHA E COLUNA DA INIMIGA COM MAIS ENERGIA*/
	int x_pos_inimiga = x_inimigas[posicao_vetor_formiga_mais_energia];
	int y_pos_inimiga = y_inimigas[posicao_vetor_formiga_mais_energia];

	/*REDUCAO DA ENERGIA DA FORMIGA INIMIGA EM 50% DA SUA ENERGIA ATUAL-->VER DESPOIS SE ISTO FUNCIONA*/
	Formigas * inimiga=f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_formiga_det_comunidade(x_pos_inimiga, y_pos_inimiga);
	int energ_formiga = inimiga->get_energia();
	//cout << energ_formiga << endl;
	inimiga->move_energia(inimiga->get_energia()-(0.5*inimiga->get_energia()));

	/*AUMENTO DA ENERGIA DA FORMIGA EM 50%*/
	f->move_energia(f->get_energia()+(0.5*energ_formiga));
}