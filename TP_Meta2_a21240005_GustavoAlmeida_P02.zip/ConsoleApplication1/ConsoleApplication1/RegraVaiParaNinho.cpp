#include "RegraVaiParaNinho.h"
#include "Comunidade.h"
#include "Tela.h"

RegraVaiParaNinho::RegraVaiParaNinho() {

}

RegraVaiParaNinho::~RegraVaiParaNinho() {

}

bool RegraVaiParaNinho::ninho_no_raio_de_visao_formiga(Formigas *f) {

	/*DEFINICAO DA POSICAO DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*DEFINICAO DOS VERTICES DO QUADRADO DO RAIO DE VISAO DA FORMIGA*/
	int x_vis_min = f->get_linha() - f->get_rv();
	int x_vis_max = f->get_linha() + f->get_rv();
	int y_vis_min = f->get_coluna() - f->get_rv();
	int y_vis_max = f->get_coluna() + f->get_rv();

	/*VERIFICACAO SE O NINHO SE ENCONTRA NO SEU RAIO DE VISAO*/
	for (int i = x_vis_min; i <= x_vis_max; ++i) {
		for (int j = y_vis_min; j <= x_vis_max; ++j) {
			if (f->pergunta_ninho_linha() == i && f->pergunta_ninho_coluna() == j) {
				return true;
			}
		}
	}
	return false;
}

bool RegraVaiParaNinho::ninho_no_raio_de_movimento_formiga(Formigas *f) {

	/*DEFINICAO DA POSICAO DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*DEFINICAO DOS VERTICES DO QUADRADO DO RAIO DE MOVIMENTO DA FORMIGA*/
	int x_mov_min = f->get_linha() - f->get_rm();
	int x_mov_max = f->get_linha() + f->get_rm();
	int y_mov_min = f->get_coluna() - f->get_rm();
	int y_mov_max = f->get_coluna() + f->get_rm();

	/*VERIFICACAO SE O NINHO SE ENCONTRA NO SEU RAIO DE MOVIMENTO*/
	for (int i = x_mov_min; i <= x_mov_max; ++i) {
		for (int j = y_mov_min; j <= x_mov_max; ++j) {
			if (f->pergunta_ninho_linha() == i && f->pergunta_ninho_coluna() == j) {
				return true;
			}
		}
	}
	return false;
}

bool RegraVaiParaNinho::condicao_regra(Formigas *f){
	if ((f->get_energia() > f->get_energia_inicial()) || (f->get_energia() < f->get_energia_inicial()*0.5)) {
		if (this->ninho_no_raio_de_visao_formiga(f) == true) {
			if (f->retorna_minha_comunidade()->retorna_tela_comunidade()->get_numero_iteracoes() - f->get_entrei_ninho() >= 10) {
				return true;
				}
			}
		}
return false;
}

void RegraVaiParaNinho::executa_regra(Formigas *f) {
	
	/*VERIFICACAO SE O NINHO SE ENCONTRA OU NAO NO SEU RAIO DE MOVIMENTO*/
	if (this->ninho_no_raio_de_movimento_formiga(f) == true) {/*A FORMIGA MOVE SE PARA DENTRO DO NINHO*/
		f->move_patas(f->pergunta_ninho_linha(), f->pergunta_ninho_coluna());
	}
	else {/*A FORMIGA MOVE SE PARA A DIRECCAO DO SEU NINHO*/
		/*VETOR QUE GUARDA A POSICAO APROXIMADA AO NINHO DADA A SUA POSICAO, O METODO SERVE PARA FORMIGAS, MIGALHAS E NINHO, VISTO QUE RECEBENDO A POSICAO DE UMA FORMIGA E A POSICAO DE ALGO A APROXIMAR, CALCULA A SUA APROXIMACAO*/
		vector<int> nova_posicao;
		nova_posicao = Regras::aproximacao_formiga_inimiga_ou_migalha(f, f->pergunta_ninho_linha(), f->pergunta_ninho_coluna());
		
		/*FORMIGA MOVE SE PARA A POSICAO APROXIMADA*/
		f->move_patas(nova_posicao[0], nova_posicao[1]);
	}
}