#include "RegraPasseia.h"

RegraPasseia::RegraPasseia() {

}

RegraPasseia::~RegraPasseia() {

}

bool RegraPasseia::condicao_regra(Formigas *f) {
	return true;
}

void RegraPasseia::executa_regra(Formigas *f) {
	//imaginemos que uma formiga se encontra na posicao (8,0)
	//a formiga para respeitar o seu raio de movimento  ela apenas se pode deslocar para posicoes compreendidas entre:
	//Este exemplo � para o caso da formiga Exploradora, se fosse outra apenas alterava o raio de movimento, a ideia � a mesma
	//					(16,0)
	//(0,0)				(8,0)			(16,0)
	//					(0,0)

	//obtencao das coordenadas iniciais, onde se encontra a formiga
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();
	//agora vou definir "a area" onde a formiga se pode deslocar//-->a area onde se pode deslocar � definido entre (x_max-x_min;y_max-y_min)
	int x_min_permitido = x_inicio - f->get_rm();
	int x_max_permitido = x_inicio + f->get_rm();
	int y_min_permitido = y_inicio - f->get_rm();
	int y_max_permitido = y_inicio + f->get_rm();
	//array bidimensional, conteudo as posicoes validas
	vector<int> x_valido;
	vector<int> y_valido;
	//nestes dois ciclos defino as posicoes permitidas para a formiga se deslocar, por exemplo verifico se a posicao (9,1) esta vazia e respeita os limites, depois passa � (9,2), ou seja percorro todas as posicoes para as quais a formigas se pode mover
	for (int i = x_min_permitido; i < x_max_permitido; ++i) {
		for (int j = y_min_permitido; j < y_max_permitido; ++j) {
			if (f->posso_andar(i, j) == true) {
				//insiro no array das posicoes validas
				x_valido.push_back(i);
				y_valido.push_back(j);
			}
		}
	}

	//matriz onde irao ser colocados os valores gerados aleatoriamente
	int numeros_aleatorios[2];

	//geracao de um numero aleatorio em x
	//criar um novo vector//-->para nao estragar o vetor que contem os x_validos
	//neste novo vetor, vou fazer um random_shuffle e escolher a 1 posicao
	//depois vou armazenar o valor escolhido e dps vou verificar qual a posicao correta onde esta atraves do vetor x_valido que continua intacto
	//e coloco as posicoes onde aparecia, se for mais que uma
	//e com essas posicoes volto a fazer um random_shuffle dessas posicoes e a 1 posicao que encontrei, vou ao y_valido e essa posicao ira conter o y aleatorio
	vector<int> temporario;
	temporario = x_valido;
	if (!x_valido.empty()) {
		std::random_shuffle(temporario.begin(), temporario.end()/*, unsigned(time(0))*/);//dps ver isto do tempo//-->se esta a trabalhar bem
		numeros_aleatorios[0] = temporario[0];
	}
	else {//se estiver vazio nao encontrou posicao nenhuma para onde ir e saio
		return;
	}

	//necessito de verificar "uma das posicoes onde estava o x seleccionado, para dps escolher o y da msm posicao
	vector<int> posicao;
	for (size_t i = 0; i < x_valido.size(); ++i) {
		if (x_valido[i] == numeros_aleatorios[0]) {//coloco no vector as posicoes onde encontrei o x seleccionado
			posicao.push_back(i);
		}
	}

	//tendo agora as posicoes onde encontrei o x_seleccionado, vou baralhar o vetor com as posicoes
	random_shuffle(posicao.begin(), posicao.end());

	//quando encontrar a 1 posicao do vetor posicao no vetor dos y tenho o meu y_sorteado
	int sair = 0;
	for (size_t i = 0; i < y_valido.size(); ++i) {
		if (i == posicao[0]) {
			numeros_aleatorios[1] = y_valido[i];
		}
	}

	//em principio faco aqui o set da nova posicao da formiga
	f->move_patas(numeros_aleatorios[0], numeros_aleatorios[1]);
	//no final perde energia 1+(movimento da formiga)
	int energia_remover = 1 + abs(x_inicio - numeros_aleatorios[0]) + abs(y_inicio - numeros_aleatorios[1]);
	f->move_energia(f->get_energia() - energia_remover);//energia passa a ser a energia que tenho - o que andou
}