#pragma once
#ifndef REGRAPASSEIA_H
#define REGRAPASSEIA_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraPasseia : public Regras {

public:
	RegraPasseia();
	~RegraPasseia();
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraPasseia(*this); }
};

#endif // !REGRAPASSEIA_H
