#include "RegraDestroiComida.h"
#include "Comunidade.h"
#include "Tela.h"


RegraDestroiComida::RegraDestroiComida() {

}

RegraDestroiComida::~RegraDestroiComida() {

}

int RegraDestroiComida::quantas_migalhas_no_raio_movimento(Formigas *f) {
	
	/*POSICOES INICIAIS DA FORMIGA*/
	int x_inicial = f->get_linha();
	int y_inicial = f->get_coluna();

	/*DEFINICAO DOS VERTICES PARA OS QUAIS A FORMIGA SE PODE MOVER*/
	int x_mov_min = f->get_linha() - f->get_rm();
	int x_mov_max = f->get_linha() + f->get_rm();
	int y_mov_min = f->get_coluna() - f->get_rm();
	int y_mov_max = f->get_coluna() + f->get_rm();

	/*VARIAVEL ONDE E INCREMENTADO O NUMERO DE MIGALHAS ENCONTRADAS PELA FORMIGA, E DEPOIS RETORNA ESSE VALOR*/
	int quantas = 0;

	/*A FORMIGA VERIFICA SE EM ALGUMA DESSAS CELULAS ENCONTROU UMA MIGALHA*/
	for (int i = x_mov_min; i <= x_mov_max; ++i) {
		for (int j = y_mov_min; j <= y_mov_max; ++j) {
			if (f->encontrei_migalha(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
				quantas++;
			}
		}
	}
	return quantas;
}

bool RegraDestroiComida::condicao_regra(Formigas *f) {
	if (this->quantas_migalhas_no_raio_movimento(f) > 0) {
		return true;
	}
	return false;
}

void RegraDestroiComida::executa_regra(Formigas *f) {

	/*POSICOES INICIAIS DA FORMIGA*/
	int x_inicial = f->get_linha();
	int y_inicial = f->get_coluna();

	/*DEFINICAO DOS VERTICES PARA OS QUAIS A FORMIGA SE PODE MOVER*/
	int x_mov_min = f->get_linha() - f->get_rm();
	int x_mov_max = f->get_linha() + f->get_rm();
	int y_mov_min = f->get_coluna() - f->get_rm();
	int y_mov_max = f->get_coluna() + f->get_rm();

	/*VETORES QUE IRA0 CONTER AS POSICOES DE TODAS AS MIGALHAS QUE SE ENCONTRAM NO RAIO DE MOVIMENTO DA FORMIGA*/
	vector<int> x_migalhas;
	vector<int> y_migalhas;

	/*A FORMIGA VERIFICA SE ENCONTROU ALGUMA MIGALHA NO SEU RAIO DE MOVIMENTO*/
	for (int i = x_mov_min; i <= x_mov_max; ++i) {
		for (int j = y_mov_min; j <= y_mov_max; ++j) {
			if (f->encontrei_migalha(i, j) == true && (i != f->get_linha() || j != f->get_coluna())) {
				x_migalhas.push_back(i);
				y_migalhas.push_back(j);
			}
		}
	}

	/*VERIFICACAO DE QUANTAS MIGALHAS EXISTEM NO SEU RAIO DE MOVIMENTO, PARA DEPOIS SUBTRAIR � SUA ENERGIA*/
	int numero_migalhas = x_migalhas.size();//podia ter recorrido ao y_migalhas, ambos tem o mesmo size por isso � igual

	/*A ENERGIA DAS MIGALHA PASSA A 0, E A MIGALHA INFORMA O MUNDO QUE MORREU*/
	for (int i = 0; i < x_migalhas.size(); ++i) {
		for (int j = 0; j < y_migalhas.size(); ++j) {
			if (i == j) {
				Migalhas *k = f->retorna_minha_comunidade()->retorna_tela_comunidade()->retorna_migalha(x_migalhas[i], y_migalhas[j]);
				k->move_energia(0);
				k->verifica_energia();
			}
		}
	}

	//cout << "\nhdhshs\n";

	/*A FORMIGA PERDE ENERGIA, IGUAL AO NUMERO DE MIGALHAS QUE MATOU*/
	f->move_energia(f->get_energia() - numero_migalhas);

}