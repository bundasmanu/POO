#include "RegraProtege.h"

RegraProtege::RegraProtege() {

}

RegraProtege::~RegraProtege() {

}

bool RegraProtege::formiga_amiga_no_raio_visao(Formigas *f) {
	
	/*OBTENCAO DA POSICAO ATUAL DA FORMIGA PASSADA POR ARGUMENTO*/
	int x_pos = f->get_linha();
	int y_pos = f->get_coluna();

	/*DEFINICAO DOS VERTICES DO QUADRADO QUE A FORMIGA VISUALIZA*/
	int x_vis_min = f->get_linha() - f->get_rv();
	int x_vis_max = f->get_linha() + f->get_rv();
	int y_vis_min = f->get_coluna() - f->get_rv();
	int y_vis_max = f->get_coluna() + f->get_rv();

	/*VERIFICACAO DENTRO DO QUADRADO, SE EXISTEM FORMIGAS QUE PERTENCEM A SUA COMUNIDADE*/
	for (int i = x_vis_min; i <= x_vis_max; ++i) {
		for (int j = y_vis_min; j <= y_vis_max; ++j) {
			if (f->encontrei_amiga(i, j) == true && (i!=f->get_linha() || j!=f->get_coluna())) {
				return true;
			}
		}
	}
	return false;
}

vector<int> RegraProtege::retorna_posicao_inimiga(Formigas *f) {
	vector<int> pos;

	for (int i = f->get_linha()-f->get_rv(); i <= f->get_linha() + f->get_rv(); ++i) {
		for (int j = f->get_linha() + f->get_rv(); j <= f->get_coluna() + f->get_rv(); ++j) {
			if (f->encontrei_inimiga(i, j) == true) {
				//cout << "\ninimigas\n";
				pos.push_back(i);
				pos.push_back(j);
				//cout << "\ninimigas\n";
				return pos;
			}
		}
	}

}

vector<int> RegraProtege::posicionamento_entre_formiga_amiga_e_inimiga(Formigas *f, int x_amiga, int y_amiga, int x_inimiga, int y_inimiga) {
	/*A Formiga passada por argumento, e que vai proteger a sua amiga da inimiga,
	ira posicionar-se numa posicao intermedia entre a formiga amiga e a inimiga, entao
	tendo as posicoes das formigas, e mediante o raio de movimento da formiga a analisar,
	gero uma posicao enquadrada no seu raio de movimento e entre as formigas*/

	/*VETORES QUE IRAO CONTER AS POSICOES INTERMEDIAS PARA AS QUAIS A FORMIGA SE PODE MOVER*/
	vector<int> x_opcoes;
	vector<int> y_opcoes;

	//cout << "\ntrack5\n";

	if (x_amiga >= x_inimiga && y_amiga >= y_inimiga) {/*1 SITUACAO*/
		for (int i = x_inimiga; i <= x_amiga; ++i) {
			for (int j = y_inimiga; j <= y_amiga; ++j) {
				if (f->posso_andar(i, j) == true && (i>=f->get_linha()-f->get_rm() || i<=f->get_linha()+f->get_rm()) && (j>=f->get_coluna()-f->get_rm()|| j<=f->get_coluna()+f->get_rm())) {
					x_opcoes.push_back(i);
					y_opcoes.push_back(j);
				}
			}
		}
	}
	if (x_inimiga >= x_amiga && y_inimiga >= y_amiga) {/*2 SITUACAO*/
		for (int i = x_amiga; i <= x_inimiga; ++i) {
			for (int j = y_amiga; j <= y_inimiga; ++j) {
				if (f->posso_andar(i, j) == true && (i >= f->get_linha() - f->get_rm() || i <= f->get_linha() + f->get_rm()) && (j >= f->get_coluna() - f->get_rm() || j <= f->get_coluna() + f->get_rm())) {
					x_opcoes.push_back(i);
					y_opcoes.push_back(j);
				}
			}
		}
	}
	if (x_inimiga >= x_amiga && y_inimiga <= y_amiga) {/*3 SITUACAO*/
		for (int i = x_amiga; i <= x_inimiga; ++i) {
			for (int j = y_inimiga; j <= y_amiga; ++j) {
				if (f->posso_andar(i, j) == true && (i >= f->get_linha() - f->get_rm() || i <= f->get_linha() + f->get_rm()) && (j >= f->get_coluna() - f->get_rm() || j <= f->get_coluna() + f->get_rm())) {
					x_opcoes.push_back(i);
					y_opcoes.push_back(j);
				}
			}
		}
	}
	if (x_inimiga<=x_amiga && y_inimiga>=y_amiga) {/*4 SITUACAO*/
		for (int i = x_inimiga; i <= x_amiga; ++i) {
			for (int j = y_amiga; j <= y_inimiga; ++j) {
				if (f->posso_andar(i, j) == true && (i >= f->get_linha() - f->get_rm() || i <= f->get_linha() + f->get_rm()) && (j >= f->get_coluna() - f->get_rm() || j <= f->get_coluna() + f->get_rm())) {
					x_opcoes.push_back(i);
					y_opcoes.push_back(j);
				}
			}
		}
	}

	//cout << "\ntrack6\n";

	/*VETOR QUE CONTEM A POSICAO INTERMEDIA PARA ONDE IRA A FORMIGA*/
	vector<int> nova_posicao;

	/*TENDO AGORA TODAS AS POSICOES INTERMEDIAS POSSIVEIS, SORTEIO UMA*/
	if (x_opcoes.size() == 1 && y_opcoes.size() == 1) {
		nova_posicao.push_back(x_opcoes[0]);
		nova_posicao.push_back(y_opcoes[0]);
	}
	else if (x_opcoes.size() == 0 && y_opcoes.size() == 0) {/*CASO NAO HAJA ESPACO PARA IR PARA UMA POSICAO INTERMEDIA, MANTEM-SE NA POSICAO ATUAL*/
		nova_posicao.push_back(f->get_linha());
		nova_posicao.push_back(f->get_coluna());
	}
	else {/*CASO HAJAM VARIAS OPCOES, � FEITO UM SORTEIO*/
		std::default_random_engine generator((unsigned int)time(0));
		std::uniform_int_distribution<int> distribution(0, x_opcoes.size()-1);//retorna uma posicao aleatoria
		int posicao_aleatoria = distribution(generator);//gero numero aleatorio de uma das posicoes do vetor de posicoes permitidas opostas
		nova_posicao.push_back(x_opcoes[posicao_aleatoria]);
		nova_posicao.push_back(y_opcoes[posicao_aleatoria]);
	}
	//cout << "\ntrack7\n";

	return nova_posicao;
}

bool RegraProtege::condicao_regra(Formigas *f) {
	if (Regras::verifica_formiga_inimiga_raio_visao(f) == true && this->formiga_amiga_no_raio_visao(f) == true) {
		return true;
	}
	return false;
}

void RegraProtege::executa_regra(Formigas *f) {
	/*OBTENCAO DA POSICAO DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*POSICOES QUE PODEM SER MOVIMENTADAS PELA FORMIGA*/
	int x_max_vis = x_inicio + f->get_rv();
	int x_min_vis = x_inicio - f->get_rv();
	int y_min_vis = y_inicio - f->get_rv();
	int y_max_vis = y_inicio + f->get_rv();

	/*VARIAVEIS DE X E Y QUE GUARDA AS POSICAO DA FORMIGA INIMIGA*/
	//vector<int> pos_ini = this->retorna_posicao_inimiga(f);
	int x_inimiga;
	int y_inimiga; 

	/*VARIAVEIS X E Y QUE GUARDAM A POSICAO DA FORMIGA AMIGA*/
	int x_amiga;
	int y_amiga;

	/*VARIAVEL QUE CONTROLA O CICLO QUANDO ENCONTRA A FORMIGA INIMIGA E A AMIGA*/
	int termina_ciclo = 0;
	
	/*VARIAVEIS QUE CONTROLAM QUE DEPOIS DE ENCONTRAR UMA INIMIGA NAO VOLTO A ENTRAR NO IF DAS INIMIGAS, O MESMO PARA AS AMIGAS*/
	int entrei_inimiga = 0;
	int entrei_amiga = 0;

	//cout << "\ntrack1\n";


	for (int i = x_min_vis; i < x_max_vis; ++i) {
		for (int j = y_min_vis; j < y_max_vis; ++j) {
			if (f->encontrei_inimiga(i, j) == true && (i != f->get_linha() || j != f->get_coluna()) && termina_ciclo == 0) {
				//cout << "\ninimigas\n";
				x_inimiga = i;
				y_inimiga = j;
				//cout << "\ninimigas\n";
				termina_ciclo++;
			}
		}
	}


	/*PERCORRER AS POSICOES PARA AS QUAIS A FORMIGA PODE ACEDER-->CONCENTRA-SE APENAS NA 1 FORMIGA AMIGA E INIMIGA QUE ENCONTRAR, VISTO QUE PODEM EXISTIR 2 INIMIGAS E 1 AMIGA, POR EXEMPLO*/
	termina_ciclo = 0;
	for (int i = x_min_vis; i <= x_max_vis; ++i) {
		for (int j = y_min_vis; j <= y_max_vis; ++j) {
			if (f->encontrei_amiga(i, j) == true && (i!=f->get_linha() || j!=f->get_coluna())&& termina_ciclo==0) {
				//cout << "\namigas\n";
				x_amiga = i;
				y_amiga = j;
				//cout << "\namigas\n";
				termina_ciclo++;
			}
		}
	}

	//cout << "\ntrack2\n";

	/*VETOR COM A NOVA POSICAO DA FORMIGA*/
	vector<int>nova_pos;

	//cout << "\ntrack3\n";

	/*CHAMADA � FUNCAO*/
	nova_pos = this->posicionamento_entre_formiga_amiga_e_inimiga(f, x_amiga, y_amiga, x_inimiga, y_inimiga);

	//cout << "\ntrack4\n";

	/*A FORMIGA MOVIMENTA SE PARA A SUA NOVA POSICAO*/
	f->variacao_energia(nova_pos[0], nova_pos[1]);
	f->move_patas(nova_pos[0], nova_pos[1]);

}