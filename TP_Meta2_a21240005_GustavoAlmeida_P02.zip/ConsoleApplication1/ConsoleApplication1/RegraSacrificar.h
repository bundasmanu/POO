#pragma once
#ifndef REGRASSACRIFICAR_H
#define REGRASSACRIFICAR_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class Regrassacrificar : public Regras{

public:
	Regrassacrificar();
	~Regrassacrificar();
	bool formiga_inimiga_no_raio_movimento(Formigas *);
	bool formiga_amiga_no_raio_movimento(Formigas *);
	int formiga_amiga_menos_energia(Formigas *f, vector<int>, vector<int>);//retorna a posicao onde se encontra a formiga amiga com menos energia
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new Regrassacrificar(*this); }
};

#endif // !REGRASSACRIFICAR_H

