#include "Vigilante.h"
#include "RegraProtege.h"
#include "RegraComeMigalha.h"
#include "RegraProcuraMigalha.h"
#include "RegraPasseia.h"

Vigilante::Vigilante(int l, int c) : Formigas(150,7, 5, l, c, 0.25), letra('V') {
	this->meu_n_serie = new int(Formigas::get_nserie());
	Formigas::acrescenta_regras(new RegraProtege());
	Formigas::acrescenta_regras(new RegraComeMigalha());
	Formigas::acrescenta_regras(new RegraProcuraMigalha());
	Formigas::acrescenta_regras(new RegraPasseia());
}

string Vigilante::Obtem_info() {
	ostringstream frase;
	frase << "Formiga\n Numero de Serie: " << this->get_nserie() << " Tipo Formiga: " << this->letra << endl;
	frase << Formigas::Obtem_info();
	return frase.str();
}

char Vigilante::Obtem_car() {
	return this->letra;
}

int Vigilante::get_rm() const {
	return Formigas::get_rm();
}

int Vigilante::get_rv() const {
	return Formigas::get_rv();
}

double Vigilante::get_energia_retira_migalha() const {
	return Formigas::get_energia_retira_migalha();
}

int Vigilante::get_nserie() const{
	return *meu_n_serie;
}

void Vigilante::desenha_formiga(int cor) {
	Formigas::desenha_formiga(cor);
}

void Vigilante::Comportamento() {
	Formigas::Comportamento();
}

void Vigilante::variacao_energia(int ll, int cc) {
	int e = Formigas::get_energia();
	int x = Formigas::get_linha();
	int y = Formigas::get_coluna();
	int abs1 = abs(x - ll);
	int abs2 = abs(y - cc);
	int energia_remover = 1 + abs1 + abs2;
	//cout << "\n" << energia_remover << endl;
	this->set_energia(Formigas::get_energia() - energia_remover);
}

Vigilante::Vigilante(const Vigilante &v) : Formigas(v){
	this->letra = v.letra;
	this->meu_n_serie = new int(v.get_nserie());
}

Vigilante & Vigilante::operator=(const Vigilante &v) {
	delete this->meu_n_serie;

	/*redefinicao dos atributos*/
	Formigas::operator=(v);
	this->letra = v.letra;
	this->meu_n_serie = new int(v.get_nserie());
	return (*this);
}