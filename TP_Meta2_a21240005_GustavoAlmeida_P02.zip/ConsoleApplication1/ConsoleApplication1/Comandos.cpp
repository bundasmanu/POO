#include "Comandos.h"

Comandos::Comandos(){
}

Comandos::~Comandos() {
	delete t;
	
	vector<Tela*>::iterator i = this->copias.begin();
	while (i != this->copias.end()) {
		delete(*i);
		i = this->copias.erase(i);
	}
}

int Comandos::get_contador() const {
	return this->contador;
}

int Comandos::get_n() const {
	return this->n;
}

bool Comandos::apenas_digitos(string validar) {
	return validar.find_first_not_of("0123456789") == string::npos;
}

int Comandos::get_tamanho_tela() const {
	return this->t->get_linhas();
}

void Comandos::executa(string fich) {
	ifstream ficheiro(fich);
	string linha;
	vector<string> tt;
	string t;
	int w = 0;
	if (ficheiro.is_open()) {//verifico se o ficheiro existe
		if (ficheiro.good()) {//se nao esta vazio
			while (getline(ficheiro, linha)) {//leio linha toda
				stringstream separador(linha);//coloco a linha na stringstream
				while (separador.good()) {
					separador >> t;//vou colocando as palavras na string t
					tt.push_back(t);
				}

				/*CICLO PARA OS COMANDOS OBRIGATORIOS*/
				for (size_t i = 0; i < this->c.size(); ++i) {
					if (tt[0].compare(this->c[i]) == 0) {//comprara com o vetor
						if (this->c[i].compare("defmundo") == 0 && !tt[1].empty()) {//se o comando for o defmundo
							int numero = stoi(tt[1]);//converto a string para um numero
							if (numero >= 10) {//o tamanho da tela tem de ser >=10
								cout << "\nA executar comando defmundo\n";
								this->defmundo(numero);
								contador++;//incremento o contador
								w++;
								//this->apaga_string_vec(tt[0]);//apago porque nao posso mais voltar a verificar este comando
							}
						}
					}
					if (tt[0].compare(this->c[i]) == 0) {
						if (this->c[i].compare("defen") == 0 && !tt[1].empty()) {
							int numero = stoi(tt[1]);
							cout << "\nA executar comando defen\n";
							this->defen(numero);
							contador++;
						}
					}
					if (tt[0].compare(this->c[i]) == 0) {
						if (this->c[i].compare("defpc") == 0 && !tt[1].empty()) {
							cout << "\nA executar comando defvt\n";
							this->defpc(stoi(tt[1]));
							contador++;
						}
					}
					if (tt[0].compare(this->c[i]) == 0) {
						if (this->c[i].compare("defmi") == 0 && this->apenas_digitos(tt[1]) == true) {
							cout << "\nA executar comando defmi\n";
							this->defmi(stoi(tt[1]));
							contador++;
						}
					}
					if (tt[0].compare(this->c[i]) == 0) {
						if (this->c[i].compare("defme") == 0 && this->apenas_digitos(tt[1]) == true) {
							cout << "\nA executar comando defme\n";
							this->defme(stoi(tt[1]));
							contador++;
						}
					}
					if (tt[0].compare(this->c[i]) == 0) {
						if (this->c[i].compare("defnm") == 0 && this->apenas_digitos(tt[1]) == true) {
							cout << "\nA executar comando defnm\n";
							this->defnm(stoi(tt[1]));
							contador++;
						}
					}
				}

				if (tt[0].compare("listamundo") == 0 || tt[0].compare("tempo") == 0 || tt[0].compare("listaninho") == 0 || tt[0].compare("ninho")==0 || tt[0].compare("listaposicao")==0 || tt[0].compare("criaf")==0 || tt[0].compare("defvt")==0 || tt[0].compare("migalha")==0 || tt[0].compare("cria1")==0 || tt[0].compare("energninho")==0 || tt[1].compare("energformiga")==0 || tt[0].compare("mata")==0 || tt[0].compare("inseticida")==0) {//se 2 elemento do vetor de strings esta vazio, li apenas listamundo, e � exatamento aquilo que pretendo, que o utilizador tenha escrito apenas listamundo, e n�o por exemplo listamundo 1
					if (tt[0].compare("listamundo") == 0) {
						cout << "\nA executar comando listamundo\n";
						this->lista_mundo();
					}
					if (tt[0].compare("tempo") == 0) {
						cout << "\nA executar comando tempo\n";
						this->tempo();
					}
					if (tt[0].compare("defvt") == 0 && !tt[1].empty() && this->apenas_digitos(tt[1]) == true) {
						cout << "\nA executar comando defvt\n";
						this->defvt(stoi(tt[1]));
					}
					if (tt[0].compare("migalha") == 0 && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[2]) == true && !tt[1].empty() && !tt[2].empty()) {
						cout << "\nA executar comando migalha\n";
						this->migalha(stoi(tt[1]), stoi(tt[2]));
					}

					if (tt[0].compare("listaninho") == 0 && !tt[1].empty() && this->apenas_digitos(tt[1]) == true) {
						cout << "\nA executar comando listaninho\n";
						this->lista_ninho(stoi(tt[1]));
					}
					if (tt[0].compare("listaposicao") == 0 && !tt[1].empty() && !tt[2].empty() && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[2]) == true) {
						cout << "\nA executar comando listaposicao\n";
						this->lista_por_posicao(stoi(tt[1]), stoi(tt[2]));
					}
					if (tt[0].compare("ninho") == 0 && !tt[1].empty() && !tt[2].empty() && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[2]) == true) {
						cout << "\nA executar comando ninho\n";
						this->cria_ninho(stoi(tt[1]), stoi(tt[2]));
					}
					if (tt[0].compare("criaf") == 0 && !tt[1].empty() && !tt[2].empty() && !tt[3].empty() && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[3]) == true) {
						cout << "\nA executar comando criaf\n";
						char c = toupper(tt[2][0]);
						for (int i = 0; i < stoi(tt[1]); ++i) {
							int k[2];
							this->gera_numeros_aleatorio(k);
							this->cria_f(c, stoi(tt[3]), k[0], k[1]);
						}
					}
					if (tt[0].compare("cria1") == 0 && !tt[1].empty() && !tt[2].empty() && !tt[3].empty() && !tt[4].empty() && this->apenas_digitos(tt[2]) == true && this->apenas_digitos(tt[3]) == true && this->apenas_digitos(tt[4]) == true) {
						char c = toupper(tt[1][0]);
						cout << "\nA executar comando cria1\n";
						this->cria_1(c, stoi(tt[2]), stoi(tt[3]), stoi(tt[4]));
					}
					if (tt[0].compare("energninho") == 0 && !tt[1].empty() && !tt[2].empty() && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[2]) == true) {
						cout << "\nA executar comando energninho\n";
						this->energninho(stoi(tt[1]), stoi(tt[2]));
					}
					if (tt[0].compare("energformiga") == 0 && !tt[1].empty() && !tt[2].empty() && !tt[3].empty() && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[2]) == true && this->apenas_digitos(tt[3]) == true) {
						cout << "\nA executar comando energformiga\n";
						this->energformiga(stoi(tt[1]), stoi(tt[2]), stoi(tt[3]));
					}
					if (tt[0].compare("mata") == 0 && !tt[1].empty() && !tt[2].empty() && this->apenas_digitos(tt[1]) == true && this->apenas_digitos(tt[2]) == true) {
						cout << "\nA executar comando mata\n";
						this->mata(stoi(tt[1]), stoi(tt[2]));
					}
					if (tt[0].compare("inseticida") == 0 && !tt[1].empty() && this->apenas_digitos(tt[1]) == true) {
						cout << "\nA executar o comando inseticida\n";
						this->inseticida(stoi(tt[1]));
					}

					k.Desenho_nova_iteracao();
					k.Desenho_apaga_ecra();
					this->t->desenha_tela();
					k.Desenha_mundo(this->t->get_linhas());
					k.Desenho_nova_iteracao();
					k.Desenho_apaga_ecra();
					k.Desenho_abertura_inicio();
				}
				//fazer clear ao vector temporario que aloco o que leio em cada frase
				tt.clear();
			}
		}
		if (w == 1) {//quando executa os comandos iniciais para fazer o enter
			k.Desenho_nova_iteracao();
			w = 0;
		}
	}
	else {
		cout << "Erro na abertura do ficheiro.\n";
	}
	ficheiro.close();
	return;
}

bool Comandos::apaga_string_vec(string x) {
	vector<string>::iterator i = this->c.begin();
	while (i != this->c.end()) {
		if (i->compare(x) == 0) {
			i = c.erase(i);
			return true;
		}
		else {
			++i;
		}
	}
	return false;
}

void Comandos::defmundo(int lim) {//lim-->corresponde ao n�mero de linhas da tela
	//construcao da tela
	this->t = new Tela(lim,"default");
	cout << "\nMundo criado\n";
}

void Comandos::defen(int energ) {
	Comunidade::set_energia(energ);
	cout << "\nDefinida energia inicial dos ninhos\n";
}

void Comandos::defpc(int valor) {
	Comunidade::percentagem_defpc(valor);
	cout << "\nDefinido percentagem ninho faz nova formiga\n";
}

void Comandos::defvt(int valor) {
	Comunidade::energia_defvt(valor);
	cout << "\nDefinido unidades de transferencia\n";
}

void Comandos::defmi(int valor) {
	this->n = ((this->t->get_linhas()*this->t->get_colunas()*valor)/100);
	Tela::set_percentagem_migalhas_iniciais(this->n);
	cout << "\nDefinido percentagem migalhas iniciais\n";
}

void Comandos::defme(int valor) {
	this->t->set_energia_migalhas(valor);
	cout << "\nDefinida energia das migalhas\n";
}

void Comandos::defnm(int max) {
	this->t->set_migalhas_cada_instante(max);
	cout << "\nDefinida numero maximo de formigas criadas a cada instante\n";
}

void Comandos::cria_ninho(int l, int c) {
		this->t->acrescenta_comunidade(l, c);
}

void Comandos::cria_f(char tip, int n_ninho, int l, int c) {
	this->t->acrescenta_formigas_det_comunidade(tip, n_ninho, l, c);
}

void Comandos::cria_1(char tip, int n_ninho, int l, int c) {
	this->t->acrescenta_formigas_det_comunidade(tip, n_ninho, l, c);
}

void Comandos::migalha(int l, int c) {
	if (this->t->posicao_vazia(l, c) == true && this->t->verifica_limites(l,c)==true) {
		this->t->acrescenta_migalha(l, c);
	}
	else {
		cout << "\nParametros invalidos\n";
	}
}

void Comandos::energninho(int ninho, int energ) {
	this->t->acrescenta_energia_ninho_det_comunidade(ninho,energ);
}

void Comandos::energformiga(int l, int c, int energ) {
	this->t->acrescenta_energia_formiga_det_comunidade(l, c, energ);
}

void Comandos::mata(int l, int c) {
	bool n;
	n=this->t->remove_formigas_det_comunidade(l, c);
	if (n == true) {
		cout << "\nFormiga morreu\n";
	}
	else {
		cout << "\nA formiga nao existe\n";
	}
}

void Comandos::inseticida(int n_ni) {
	bool n;
	n = this->t->remover_comunidade(n_ni);
	if (n == true) {
		cout << "\nComunidade removida com sucesso\n";
	}
	else {
		cout << "\nComunidade nao existe\n";
	}
}

void Comandos::lista_mundo() {
	cout<<this->t->lista_mundo();
}

void Comandos::lista_ninho(int n) {
	cout<<this->t->lista_por_comunidade(n);
}

void Comandos::lista_por_posicao(int l, int c) {
	cout<<this->t->lista_por_posicao_tela(l, c);
}

void Comandos::tempo() {
	int w = this->gera_numero_aleatorio(this->t->get_migalhas_cada_instante());
	this->t->atualiza_elementos_tela(w);
}

void Comandos::desenha() {
	this->t->desenha_tela();
}

int Comandos::gera_numero_aleatorio(int n) {
	std::random_device r;
	std::default_random_engine generator2(r());//antes estava aqui o unsigned int(time(0))
	std::uniform_int_distribution<int> distribution2(0, n);//area onde os elementos podem andar
	int x = distribution2(generator2);
	return x;
}

int* Comandos::gera_numeros_aleatorio(int x[]) {
//tenho de ter em atencao que s� posso gerar numeros aleatorios e inserir l� elementos, se a posicao estiver vazia
	//int x[2];
	bool confirmacao = false;
	
	//aqui esta presente o mecanismo de geracao de numeros aleatorios, recorri � biblioteca time para gerar de uma forma mais aleatoria os numeros
	std::default_random_engine generator((unsigned int)time(NULL));
	std::uniform_int_distribution<int> distribution(11, t->get_linhas() + 10);//area onde os elementos podem andar

	do {
		for (int i = 0; i < 2; ++i) {
			x[i] = distribution(generator);
		}
		//cout << "\nx[0]: " << x[0] << " e " << x[1] << "\n";
		//garanto que esta msm vazia
		if (this->t->posicao_vazia(x[0],x[1]) == true) {//so saio do ciclo se a posicao que foi gerada se encontrar vazia
			//cout << "\nA validar...\n";
			confirmacao=true;
		}

		//if aquela posicao tiver vazia, coloco bool=true senao bool=false
		//so para quando encontrar uma posicao vazia
	} while (confirmacao != true);
	//pronto depois j� posso aplicar os numeros gerados no novo elemento criado
	return x;
}

void Comandos::gera_numeros_aleatorios_formigas(int *x) {
	//tenho de ter em atencao que s� posso gerar numeros aleatorios e inserir l� elementos, se a posicao estiver vazia
	//int x[2];
	bool confirmacao = false;

	//aqui esta presente o mecanismo de geracao de numeros aleatorios, recorri � biblioteca time para gerar de uma forma mais aleatoria os numeros
	std::default_random_engine generator((unsigned int)time(NULL));
	std::uniform_int_distribution<int> distribution(11, t->get_linhas() + 10);//area onde os elementos podem andar

	do {
		for (int i = 0; i < 2; ++i) {
			x[i] = distribution(generator);
		}
		
		//garanto que esta msm vazia
		if (this->t->posicao_vazia(x[0], x[1]) == true) {//so saio do ciclo se a posicao que foi gerada se encontrar vazia
			//cout << "\nA validar...\n";
			confirmacao = true;
		}

		//if aquela posicao tiver vazia, coloco bool=true senao bool=false
		//so para quando encontrar uma posicao vazia
	} while (confirmacao != true);
	//pronto depois j� posso aplicar os numeros gerados no novo elemento criado
}

bool Comandos::grava_ficheiro(string nome_f) {//recebe como parametro o nome do ficheiro que o utilizador escreveu

	/*guarda mundo(c�pia) no vetor de copias*/
	this->copias.push_back(new Tela(*this->t));
	this->copias.back()->set_nome(nome_f);

/*	Tela *stringnomef=new Tela(*this->t);//construtor por copia
	cout<<stringnomef->lista_por_comunidade(1);
	cout << stringnomef->lista_mundo();
	*stringnomef = *this->t;
	cout << stringnomef->lista_mundo();
	delete stringnomef;*/
	return true;
}

bool Comandos::muda_ficheiro(string nome_f) {
	
	for (size_t i = 0; i < this->copias.size(); ++i) {
		if (copias[i]->get_nome() == nome_f) {
			*this->t = *copias[i];
			return true;
		}
	}
	return false;
}

bool Comandos::apaga_ficheiro(string nome_f) {
	
	/*CASO SE APAGUE O MUNDO DEFAULT*/
	if (nome_f == "default") {
		contador = 0;
		delete this->t;
		t = NULL;
		//this->c.push_back("defmundo");
	}

	vector<Tela*>::iterator i = this->copias.begin();
	while (i != this->copias.end()) {
		if ((*i)->get_nome() == nome_f) {
			delete(*i);
			i = this->copias.erase(i);
			return true;
		}
		++i;
	}
	return false;
}