#pragma once
#ifndef REGRAPROTEGE_H
#define REGRAPROTEGE_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraProtege : public Regras {

public:
	RegraProtege();
	~RegraProtege();
	bool formiga_amiga_no_raio_visao(Formigas *f);
	vector<int> retorna_posicao_inimiga(Formigas *);
	vector<int> posicionamento_entre_formiga_amiga_e_inimiga(Formigas*, int, int, int, int);
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraProtege(*this); }
};

#endif // !REGRAPROTEGE_H

