#include "Assaltante.h"
#include "RegraAssalta.h"
#include "RegraPersegue.h"
#include "RegraComeMigalha.h"
#include "RegraProcuraMigalha.h"
#include "RegraPasseia.h"

Assaltante::Assaltante(int l, int c) : Formigas(80, 8, 4, l, c, 0.75), letra('A') {
	this->meu_n_serie = new int(Formigas::get_nserie());
	Formigas::acrescenta_regras(new RegraAssalta());
	Formigas::acrescenta_regras(new RegraPersegue());
	Formigas::acrescenta_regras(new RegraComeMigalha());
	Formigas::acrescenta_regras(new RegraProcuraMigalha());
	Formigas::acrescenta_regras(new RegraPasseia());
}

string Assaltante::Obtem_info() {
	ostringstream frase;
	frase << "Formiga\n Numero de Serie: " << this->get_nserie() << " Tipo Formiga: " << this->letra << endl;
	frase << Formigas::Obtem_info();
	return frase.str();
}

char Assaltante::Obtem_car() {
	return this->letra;
}

int Assaltante::get_rm() const {
	return Formigas::get_rm();
}

int Assaltante::get_rv() const {
	return Formigas::get_rv();
}

double Assaltante::get_energia_retira_migalha() const {
	return Formigas::get_energia_retira_migalha();
}

int Assaltante::get_nserie() const{
	return *meu_n_serie;
}

void Assaltante::desenha_formiga(int cor) {
	Formigas::desenha_formiga(cor);
}

void Assaltante::Comportamento() {
	Formigas::Comportamento();
}

void Assaltante::variacao_energia(int ll, int cc) {
	int e = Formigas::get_energia();
	int x = Formigas::get_linha();
	int y = Formigas::get_coluna();
	int abs1 = abs(x - ll);
	int abs2 = abs(y - cc);
	int energia_remover = 1 + 2*(abs1 + abs2);
	//cout << "\n" << energia_remover << endl;
	this->set_energia(Formigas::get_energia() - energia_remover);
}

Assaltante::Assaltante(const Assaltante &a) : Formigas(a){
	this->letra = a.letra;
	this->meu_n_serie = new int(a.get_nserie());
}

Assaltante & Assaltante::operator=(const Assaltante &a) {
	delete this->meu_n_serie;

	/*redefinicao dos novos atributos*/
	Formigas::operator=(a);//chamada do operador de atribuicao da Formiga
	this->letra = a.letra;
	this->meu_n_serie = new int(a.get_nserie());
	return (*this);
}