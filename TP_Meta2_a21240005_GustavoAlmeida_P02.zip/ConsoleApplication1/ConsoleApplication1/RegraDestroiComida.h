#pragma once
#ifndef REGRADESTROICOMIDA_H
#define REGRADESTROICOMIDA_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraDestroiComida : public Regras{

public:
	RegraDestroiComida();
	~RegraDestroiComida();
	int quantas_migalhas_no_raio_movimento(Formigas *f);
	virtual bool condicao_regra(Formigas *);
	virtual void executa_regra(Formigas *);
	Regras * clone() { return new RegraDestroiComida(*this); }
};

#endif // !REGRADESTROICOMIDA_H

