#pragma once
#ifndef DESENHO_H
#define DESENHO_H
#include<iostream>
#include<string>
#include<sstream>
#include "Consola.h"

using namespace std;

class Desenho {

public:
	Desenho();//construtor sem nada
	~Desenho();//destrutor sem nada
	void Desenho_abertura_inicio();
	void Desenho_inicio_configuracao(int);
	void Desenho_apaga_ecra();
	void Desenho_texto_padrao();
	void Desenho_nova_iteracao();
	void Desenha_mundo(int);
	void Desenho_foca_mundo(int, int);//dadas 2 posicoes foca um quadrado at� ao enquadramento da tela
};

#endif // !DESENHO_H

