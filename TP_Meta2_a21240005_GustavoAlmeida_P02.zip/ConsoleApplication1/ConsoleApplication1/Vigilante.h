#pragma once
#ifndef VIGILANTE_H
#define VIGILANTE_H
#include<iostream>
#include<string>
#include "Formigas.h"

using namespace std;

class Vigilante : public Formigas {
	char letra;//contem o caracter relativo a cada tipo de formiga
	int *meu_n_serie;
public:
	Vigilante(int, int);
	virtual ~Vigilante() { delete meu_n_serie; }
	virtual string Obtem_info();
	virtual char Obtem_car();
	virtual int get_nserie() const;
	virtual int get_rm() const;
	virtual int get_rv() const;
	virtual double get_energia_retira_migalha() const;
	virtual void desenha_formiga(int);
	virtual void Comportamento();
	virtual void variacao_energia(int, int);
	Formigas * clone() { return new Vigilante(*this); }
	Vigilante(const Vigilante &);
	Vigilante & operator=(const Vigilante &);
};

#endif // !VIGILANTE_H
