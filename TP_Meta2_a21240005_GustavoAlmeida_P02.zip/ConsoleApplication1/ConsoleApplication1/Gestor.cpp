/*Esta classe ir� substituir a classe Comandos
Esta classe ir� armazenar todos os dados relativos �s formigas,ninhos,migalhas,tela
onde ir� conter os dados,e um metodo entre outros que tem as atualizacoes em cada iteracao,
RESPEITANDO SEMPRE O ENCAPSULAMENTO*/

/*D�VIDAS:
Penso que terei de armazenar a tela,migalhas,(as comunidades ou ninho)-->necessito de confirmar isto
Como a Classe Tela ter� de armazenar todos os ninhos, para listar a informacao presente no ninho, entao posso ter de armazenar apenas a Tela
*/

/*
Aqui terei os metodos-->que dao resposta aos comandos*/

/*Atualizacao em cada iteracao*/

/*A Classe Interaccao dps apenas precisa de chamar os metodos aqui presentes*/