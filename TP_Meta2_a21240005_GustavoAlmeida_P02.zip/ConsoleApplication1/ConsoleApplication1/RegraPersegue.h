#pragma once
#ifndef REGRA_PERSEGUE_H
#define REGRA_PERSEGUE_H
#include<iostream>
#include<string>
#include "Regras.h"

using namespace std;

class RegraPersegue : public Regras {

public:
	RegraPersegue();
	~RegraPersegue();
	bool condicao_regra(Formigas *);
	void executa_regra(Formigas *);
	Regras * clone() { return new RegraPersegue(*this); }
};

#endif // !REGRA_PERSEGUE_H

