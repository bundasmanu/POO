#include "Desenho.h"

Desenho::Desenho() {

}

Desenho::~Desenho() {

}

void Desenho::Desenho_abertura_inicio() {
	Consola::clrscr();//apago o que tenho inicialmente no ecra
	Consola::setBackgroundColor(Consola::PRETO);
	Consola::setTextColor(Consola::BRANCO);
	Consola::setTextSize(15, 15);
	Consola::gotoxy(50, 0);
	cout << "------------------------------";
	Consola::gotoxy(50,2);
	cout << "BEM VINDO AO JOGO DE SIMULACAO";
	Consola::gotoxy(50, 4);
	cout << "------------------------------\n";
}

void Desenho::Desenho_inicio_configuracao(int tamanho) {
	Consola::gotoxy(tamanho, tamanho+4);
	cout << "<";
}

void Desenho::Desenho_apaga_ecra() {
	Consola::clrscr();
}

void Desenho::Desenho_texto_padrao() {
	Consola::setTextColor(Consola::BRANCO);
	Consola::setTextSize(15, 15);
}

void Desenho::Desenho_nova_iteracao() {
	//escreve no final de ser escrito no texto, por exemplo o listamundo, na proxima linha escreve digite
	cout << "\n\nDigite enter para prosseguir.\n";
	//o cursor fica na linha abaixo do cout
	char ch;
	do {
		ch = Consola::getch();
	} while (ch != char('\r'));//enquanto for diferente de enter, esta sempre a pedir novo caracter
}

//para j� trabalho com valores fixos dps passo ao tamanho real da tela
//nao esquecer que o mundo � quadrado
void Desenho::Desenha_mundo(int tamanho) {
	int x = 10;//x inicial
	int y = 10;//y inicial
	int tam = tamanho;
	int www = 10;
	string palavra_numero;
	int apenas_uma_vez = 0;
	Consola::setTextColor(Consola::BRANCO);
	//Consola::setTextSize(15, 15);
	//Consola::gotoxy(x, y);
	for (int i = 10; i < tam + 10+2; ++i) {//4*4//->necessito sempre de mais uma para que a ultima linha e coluna sejam escritas
		int controla_linha = 10;
		int controla_coluna = 10;
		int def = 0;
		if (i == 10) {
			while (def != tam+2) {//tela + 2 elementos n�o acedidos
				Consola::gotoxy(controla_coluna, i);//o x � que vai sempre aumentando
				cout << '#';

				if (controla_coluna % 2 == 0) {//faz regua de 2 em 2 cms
					ostringstream converte;
					converte << www;
					palavra_numero = converte.str();
					for (int k = 0; k < palavra_numero.length(); ++k) {
						if (palavra_numero.length() == 2) {//numeros de 10 a 100
							Consola::gotoxy(controla_coluna, i - 2+k);
							cout << palavra_numero[k];
						}
						if (palavra_numero.length() == 3) {//numeros de 100 a 999
							Consola::gotoxy(controla_coluna, i - 3 + k);
							cout << palavra_numero[k];
						}
					}
				}
				controla_coluna++;
				def++;
				www++;
			}
		}
		if (i == ((tam + 10) +1)) {//faz de 10 at� ao (tam+1)-->preenche as margens 10 e (tam+1) e o resto � o mundo que se pode percorrer--> so para quando def == tam+2, ou seja a ultima coisa a realizar � o tam+1
			while (def != tam+2) {
				Consola::gotoxy(controla_coluna, i);//o x � que vai sempre aumentando
				cout << '#';
				controla_coluna++;
				def++;
			}
		}

			for (int j = 10; j < 10 + tam + 2; j++) {
				def = 0;
				controla_linha = 10;
				int www = 10;
				if (j == 10 && apenas_uma_vez==0) {//linha vertical esquerda
					while (def != tam + 2) {
						Consola::gotoxy(j, controla_linha);//o y � que vai sempre aumentando
						cout << '#';

						if (controla_linha % 2 == 0) {
							ostringstream converte;
							converte << www;
							palavra_numero = converte.str();
							for (int k = 0; k < palavra_numero.length(); ++k) {
								if (palavra_numero.length() == 2) {//numeros de 10 a 100
									Consola::gotoxy(j - 2 + k, controla_linha);
									cout << palavra_numero[k];
								}
								if (palavra_numero.length() == 3) {//numeros de 100 a 999
									Consola::gotoxy(j - 3 + k, controla_linha);
									cout << palavra_numero[k];
								}
							}
						}
						controla_linha++;
						def++;
						www++;
					}
					apenas_uma_vez++;
				}
				if (j == (10 + (tam + 1)) && j != 10 && apenas_uma_vez==1) {
					while (def != tam + 2) {
						Consola::gotoxy(j, controla_linha);//o y � que vai sempre aumentando
						cout << '#';
						controla_linha++;
						def++;
					}
					apenas_uma_vez++;
				}
		}
	}

}

void Desenho::Desenho_foca_mundo(int l,int c) {

		/*DIFERENCAS ENTRE DIMENSOES*/
		int diferenca_x = l - (l/2);
		int diferenca_y = c - (c/2);

	/*DESENHAR AS COLUNAS MEDIANTE O CENTRO PEDIDO*/

		/*VARIAVEIS NECESSARIOS PARA FAZER A REGUA*/
		int controla_coluna = 10;
		int def = 0;
		string palavra_numero;
		int apenas_uma_vez = 0;
		int n;//controlo das linhas-->display das linhas vericais
		int n2;//controla das colunas-->dispaly das linhas horizontais
		int www;

		/*IF'S PARA ESTABELECER A AREA VISIVEL MEDIANTE A LINHA E COLUNA DIGITADA PELO UTILIZADOR*/
		if (l < 30 && l>15) {
			n = l + diferenca_x + 2;
		}
		if (l > 30) {
			n = 52;
		}

		if (c < 30 && c>15) {
			n2 = c + diferenca_y + 2;
			www = 10;
		}
		if (c > 30) {
			n2 = c+(c/2);
			www = (c / 2);
		}

		for (int i = 10; i < n; ++i) {
			if (i == 10) {/*DESENHO DA REGUA*/
				while (def != (n2-20)) {//como o def comeca em 0 tem de ser -10, se nao quisesse colocar o -10, a variavel def tinha de comecar a 10-->no m�ximo ir� at� aos 180
					Consola::gotoxy(controla_coluna, i);//o x � que vai sempre aumentando
					cout << '#';

					if (controla_coluna % 2 == 0) {//faz regua de 2 em 2 cms
						ostringstream converte;
						converte << www;
						palavra_numero = converte.str();
						for (int k = 0; k < palavra_numero.length(); ++k) {
							if (palavra_numero.length() == 2) {//numeros de 10 a 100
								Consola::gotoxy(controla_coluna, i - 2 + k);
								cout << palavra_numero[k];
							}
							if (palavra_numero.length() == 3) {//numeros de 100 a 999
								Consola::gotoxy(controla_coluna, i - 3 + k);
								cout << palavra_numero[k];
							}
						}
					}
					controla_coluna++;
					def++;
					www++;
				}
			 }
				if (i == (n-1) && apenas_uma_vez==2) {
					controla_coluna = 10;
					def = 0;
					while (def != n2 - 20) {//como o def comeca em 0 tem de ser -10, se nao quisesse colocar o -10, a variavel def tinha de comecar a 10
						Consola::gotoxy(controla_coluna, i);//o x � que vai sempre aumentando
						cout << '#';
						controla_coluna++;
						def++;
					}
				}

			/*RESET DAS VARIAVEIS, PARA EFETUAR A REGUA DAS LINHAS*/
			int controla_linha=10;

			for (int j = 10; j < n2; ++j) {
				def = 0;
				if (l < 30 && l>15) {
					www = 10;
				}
				if (l > 30) {
					www = (l / 2);
				}
				if (j == 10 && apenas_uma_vez==0) {
					while (def != n-10) {//como o def comeca em 0 tem de ser -10, se nao quisesse colocar o -10, a variavel def tinha de comecar a 10
						Consola::gotoxy(j, controla_linha);//o y � que vai sempre aumentando
						cout << '#';

						if (controla_linha % 2 == 0) {
							ostringstream converte;
							converte << www;
							palavra_numero = converte.str();
							for (int k = 0; k < palavra_numero.length(); ++k) {
								if (palavra_numero.length() == 2) {//numeros de 10 a 100
									Consola::gotoxy(j - 2 + k, controla_linha);
									cout << palavra_numero[k];
								}
								if (palavra_numero.length() == 3) {//numeros de 100 a 999
									Consola::gotoxy(j - 3 + k, controla_linha);
									cout << palavra_numero[k];
								}
							}
						}
						controla_linha++;
						def++;
						www++;
					}
					apenas_uma_vez++;
				}
				if (j == n2-10  && j != 10 && apenas_uma_vez==1) {
					def = 0;
					controla_linha = 10;
					while (def != (n-10)) {//como o def comeca em 0 tem de ser -10, se nao quisesse colocar o -10, a variavel def tinha de comecar a 10
						Consola::gotoxy(j, controla_linha);//o y � que vai sempre aumentando
						cout << '#';
						controla_linha++;
						def++;
					}
					apenas_uma_vez++;
				}
			}
		 }
}