#include "RegraProcuraMigalha.h"

RegraProcuraMigalha::RegraProcuraMigalha() {

}

RegraProcuraMigalha::~RegraProcuraMigalha() {

}

int RegraProcuraMigalha::quantas_migalhas_raio_visao(Formigas *f) {
	/*Mediante o raio de visao da formiga passada por argumento, verifico o numero
	de migalhas existentes, retornando o numero de migalhas*/

	/*POSICAO INICIAL DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*DEFINICAO DO RAIO DE VISAO DA FORMIGA*/
	int x_vis_min = f->get_linha() - f->get_rv();
	int x_vis_max = f->get_linha() + f->get_rv();
	int y_vis_min = f->get_coluna() - f->get_rv();
	int y_vis_max = f->get_coluna() + f->get_rv();

	/*VARIAVEL DE RETORNO DO NUMERO DE MIGALHAS, NO RAIO DE VISAO DA FORMIGA*/
	int numero_migalhas = 0;

	/*VERIFICACAO NO QUADRADO DE VISAO DA FORMIGA SE L� EXISTEM MIGALHAS*/
	for (int i = x_vis_min; i <= x_vis_max; ++i) {
		for (int j = y_vis_min; j <= y_vis_max; ++j) {
			if (f->encontrei_migalha(i, j) == true) {
				numero_migalhas++;
			}
		}
	}
	return numero_migalhas;
}

bool RegraProcuraMigalha::condicao_regra(Formigas *f) {
	int x = this->quantas_migalhas_raio_visao(f);
	if (x != 0) {
		return true;
	}
	return false;
}

void RegraProcuraMigalha::executa_regra(Formigas *f) {
	/*POSICAO INICIAL DA FORMIGA*/
	int x_inicio = f->get_linha();
	int y_inicio = f->get_coluna();

	/*DEFINICAO DO RAIO DE VISAO DA FORMIGA*/
	int x_vis_min = f->get_linha() - f->get_rv();
	int x_vis_max = f->get_linha() + f->get_rv();
	int y_vis_min = f->get_coluna() - f->get_rv();
	int y_vis_max = f->get_coluna() + f->get_rv();

	/*VETORES QUE CONTEM O X E Y DAS MIGALHAS EXISTENTES NO RAIO DE VISAO DA FORMIGA*/
	vector<int> x_migalhas;
	vector<int> y_migalhas;

	/*COLOCACAO DAS POSICOES DAS MIGALHAS NOS VETORES*/
	for (int i = x_vis_min; i <= x_vis_max; ++i) {
		for (int j = y_vis_min; j <= y_vis_max; ++j) {
			if (f->encontrei_migalha(i, j) == true) {
				x_migalhas.push_back(i);
				y_migalhas.push_back(j);
			}
		}
	}

	/*RETORNO DA POSICAO MIGALHA COM MAIS ENERGIA*/
	int migalha_com_mais_energia = Regras::qual_migalha_tem_mais_energia(f, x_migalhas, y_migalhas);

	/*POSICAO X E Y DA MIGALHA COM MAIS ENERGIA*/
	int x_migalha_mais_energia = x_migalhas[migalha_com_mais_energia];
	int y_migalha_mais_energia = y_migalhas[migalha_com_mais_energia];

	/*VETOR QUE CONTEM A NOVA POSICAO DA FORMIGA EM APROXIMACAO A MIGALHA*/
	vector<int>aproximacao_migalha;

	/*RETORNO DA NOVA POSICAO APROXIMADA DA FORMIGA, EM RELACAO A MIGALHA*/
	aproximacao_migalha = Regras::aproximacao_formiga_inimiga_ou_migalha(f, x_migalha_mais_energia, y_migalha_mais_energia);

	/*A FORMIGA MOVE SE PARA A SUA NOVA POSICAO*/
	f->variacao_energia(aproximacao_migalha[0], aproximacao_migalha[1]);
	f->move_patas(aproximacao_migalha[0], aproximacao_migalha[1]);

}