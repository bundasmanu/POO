#pragma once
#ifndef COMUNIDADE_H
#define COMUNIDADE_H
#include<iostream>
#include<string>
#include "Consola.h"
#include "Ninho.h"
#include "Formigas.h"
#include "Exploradora.h"
#include "Cuidadora.h"
#include "Vigilante.h"
#include "Assaltante.h"
#include "Surpresa.h"

using namespace std;

class Tela;

class Comunidade {
	Ninho *m;
	vector<Formigas*> f;
	static int energia_ninho;//valor do comando defen energia inicial igual para todos os ninhos
	static int percentagem_nova_f;
	static int valor_transf_form_nin;
	Tela *tel;
public:
	Comunidade(int,int);//recebe valor da linha e coluna a serem passados para a criacao do Ninho
	~Comunidade();
	void acrescenta_formigas(char,int,int,int);//comando criaf 
	void remove_formiga(int, int);
	bool procura_formiga(int l, int c);
	int numero_formigas();
	void remove_ninho();
	int get_nserie_ninho();
	int get_linha_ninho();//linha onde se encontra o ninho da comunidade
	int get_coluna_ninho();//coluna onde se encontra o ninho da comunidade
	int get_energia_ninho();
	int get_energia_formiga(int, int);
	string lista_comunidade();
	string lista_ninho_comunidade();
	string lista_formiga(int, int);
	void atualiza_elementos_comunidade();
	static void percentagem_defpc(int);
	int get_defpc() const;
	static void energia_defvt(int);
	int get_percentagem_defvt() const;
	static void set_energia(int);
	void desenha_comunidade(int);
	void set_tela(Tela *);
	void acabou_comunidade(int);//se a energia do ninho for <=1 pe�o a Tela que remova toda a sua Comunidade, ou seja j� nao possuir qualquer elemento na comunidade, ou seja se j� n�o existir ninho e nenhuma formiga, digo � Tela, que pode remover a comunidade
	void acrescenta_energia_ninho(int);//energia a ser acresentada
	void acrescenta_energia_formiga(int,int,int);//recebe a linha e coluna onde se encontra a formiga e o valor a acrescentar
	Tela * retorna_tela_comunidade();//retorna a tela � qual uma comunidade pertence, importante para as regras
	Formigas * retorna_formiga_da_comunidade(int, int);//retorna uma formiga pertencente � comunidade que se encontra na posi��o linha e coluna passada por argumento
	Comunidade(const Comunidade &);
	Comunidade & operator=(const Comunidade &);
};

#endif // !COMUNIDADE_h
