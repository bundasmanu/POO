#pragma once
#ifndef SURPRESA_H
#define SURPRESA_H
#include<iostream>
#include<string>
#include "Formigas.h"

using namespace std;

class Surpresa : public Formigas {
	char letra;//contem o caracter relativo a cada tipo de formiga
	int *meu_n_serie;
public:
	Surpresa(int, int);
	virtual ~Surpresa() { delete meu_n_serie; }
	virtual string Obtem_info();
	virtual char Obtem_car();
	virtual int get_nserie() const;
	virtual int get_rm() const;
	virtual int get_rv() const;
	virtual double get_energia_retira_migalha() const;
	virtual void desenha_formiga(int);
	virtual void Comportamento();
	virtual void variacao_energia(int, int);
	Formigas * clone() { return new Surpresa(*this); }
	Surpresa(const Surpresa &);
	Surpresa & operator=(const Surpresa &);
};

#endif // !SURPRESA_H

