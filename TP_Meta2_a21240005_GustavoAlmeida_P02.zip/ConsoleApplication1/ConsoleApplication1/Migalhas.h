#pragma once
#ifndef MIGALHAS_H
#define MIGALHAS_H
#include<iostream>
#include<string>
#include<sstream>
#include "Consola.h"

using namespace std;

class Tela;

class Migalhas {
	int *energia;//energia da formiga
	const int energia_inicial;
	int linha;
	int coluna;
	//Ponteiro para Tela-->para dizer a Tela que precisa de ser removida, por exemplo
	Tela *te;
public:
	Migalhas(int, int, int);
	~Migalhas();
	int get_linha() const;
	int get_coluna() const;
	int get_energia() const;
	void set_energia(int);
	void move_energia(int);
	string Obtem_info() const;
	void set_tela(Tela *);
	void verifica_energia();
	void desenha_migalha();
	int* posicao_vazia_aleatoria(int []);
	Migalhas(const Migalhas &);
	Migalhas & operator=(const Migalhas &);
};

#endif // !MIGALHAS_H
